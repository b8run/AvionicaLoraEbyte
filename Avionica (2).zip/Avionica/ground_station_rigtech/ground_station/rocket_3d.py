"""
rocket_3d.py — Rigtech Ground Station
Visualizador 3D do foguete com OpenGL + PyQt5.
"""

import math
from PyQt5.QtOpenGL import QGLWidget
from PyQt5.QtCore    import Qt
from PyQt5.QtGui     import QColor, QFont
from OpenGL.GL       import *
from OpenGL.GLU      import *

# Layout vertical do foguete (y de baixo para cima):
#   Bocal    : y=-2.30 → y=-1.76  (gera chama abaixo de -2.30)
#   Motor    : y=-1.76 → y=-1.04  (aletas fixadas aqui)
#   Anel inf : y=-1.04 → y=-0.92
#   Aviônica : y=-0.92 → y=-0.12
#   Anel sup : y=-0.12 → y=+0.12
#   Corpo    : y= 0.00 → y=+2.20
#   Ogiva    : y=+2.20 → y=+3.20

_ESTADO_NOME = {0: "AGUARDANDO", 1: "SUBIDA", 2: "DESCIDA", 3: "POUSADO"}
_ESTADO_COR  = {
    0: QColor(245, 166,  35),   # amarelo
    1: QColor( 39, 174,  96),   # verde
    2: QColor( 39, 174,  96),   # verde
    3: QColor(231,  76,  60),   # vermelho
}


class Rocket3DWidget(QGLWidget):

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(280, 380)
        self._pitch  = 90.0    # 90° = vertical
        self._roll   = 0.0
        self._estado = 0
        self._altitude = 0.0
        self._accel    = 0.0
        self._anim_t   = 0.0

    # ── API pública ───────────────────────────────────────────────────────────
    def atualizar(self, estado: int, altitude: float, aceleracao: float):
        self._estado   = estado
        self._altitude = altitude
        self._accel    = aceleracao

        # ── Pitch-alvo derivado do estado + magnitude da aceleração ──────────
        # Simula resposta do MPU: alta aceleração → vertical;
        # coast/paraquedas → inclinação crescente; pousado → horizontal.
        if estado == 0:    # AGUARDANDO
            target_pitch = 90.0

        elif estado == 1:  # SUBIDA
            # Motor ligado (acc alta) → vertical; coast (acc baixa) → leve arco
            arc = max(0.0, (28.0 - aceleracao)) * 0.55
            target_pitch = max(55.0, 90.0 - arc)

        elif estado == 2:  # DESCIDA — paraquedas oscila
            target_pitch = 74.0 + 9.0 * math.sin(self._anim_t * 0.65)

        elif estado == 3:  # POUSADO — deita suavemente
            target_pitch = 3.0

        else:
            target_pitch = 90.0

        # Interpolação suave (lerp) para transições fluidas
        self._pitch += (target_pitch - self._pitch) * 0.12

        # ── Roll — spin de estabilização durante o voo ────────────────────────
        if estado == 1:              # subindo: spin rápido
            self._roll = (self._roll + 2.0) % 360
        elif estado == 2:            # descendo: spin lento
            self._roll = (self._roll + 0.6) % 360
        elif estado == 3:            # pousado: para o spin
            self._roll += (0.0 - self._roll) * 0.06

        self._anim_t += 0.3
        self.update()

    # ── OpenGL ────────────────────────────────────────────────────────────────
    def initializeGL(self):
        glClearColor(0.06, 0.08, 0.12, 1.0)
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_LIGHTING)
        glEnable(GL_LIGHT0)
        glEnable(GL_LIGHT1)
        glEnable(GL_COLOR_MATERIAL)
        glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE)
        glShadeModel(GL_SMOOTH)

        # Luz principal (cima-direita-frente)
        glLightfv(GL_LIGHT0, GL_POSITION, [3.0, 5.0, 4.0, 1.0])
        glLightfv(GL_LIGHT0, GL_DIFFUSE,  [1.0, 1.0, 1.0, 1.0])
        glLightfv(GL_LIGHT0, GL_AMBIENT,  [0.14, 0.14, 0.18, 1.0])

        # Luz de preenchimento (baixo-esquerda)
        glLightfv(GL_LIGHT1, GL_POSITION, [-2.0, -3.0, 2.0, 1.0])
        glLightfv(GL_LIGHT1, GL_DIFFUSE,  [0.20, 0.22, 0.30, 1.0])
        glLightfv(GL_LIGHT1, GL_AMBIENT,  [0.0,  0.0,  0.0,  1.0])

    def resizeGL(self, w, h):
        if h == 0:
            h = 1
        glViewport(0, 0, w, h)
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        gluPerspective(45.0, w / h, 0.1, 100.0)
        glMatrixMode(GL_MODELVIEW)

    def paintGL(self):
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glLoadIdentity()

        # Câmera centrada no meio do foguete (~y=0.45)
        gluLookAt(0, 0.45, 9,   0, 0.45, 0,   0, 1, 0)

        glRotatef(-(self._pitch - 90), 1, 0, 0)
        glRotatef(self._roll,           0, 0, 1)

        self._draw_rocket()
        if self._estado == 1 or self._accel > 30:
            self._draw_flame()

        self._draw_hud()

    # ── Geometrias ────────────────────────────────────────────────────────────
    def _draw_rocket(self):
        q = gluNewQuadric()
        gluQuadricNormals(q, GLU_SMOOTH)

        # ── Ogiva / Nose cone (vermelho) ──────────────────────────────────────
        glColor3f(0.85, 0.12, 0.12)
        glPushMatrix()
        glTranslatef(0, 2.20, 0)
        glRotatef(-90, 1, 0, 0)
        gluCylinder(q, 0.40, 0.00, 1.00, 24, 8)
        gluDisk(q, 0, 0.40, 24, 1)          # disco base da ogiva
        glPopMatrix()

        # ── Corpo principal (branco) ──────────────────────────────────────────
        glColor3f(0.92, 0.92, 0.95)
        glPushMatrix()
        glRotatef(-90, 1, 0, 0)
        gluCylinder(q, 0.40, 0.40, 2.20, 24, 1)
        gluDisk(q, 0, 0.40, 24, 1)          # fundo do corpo
        glTranslatef(0, 0, 2.20)
        gluDisk(q, 0, 0.40, 24, 1)          # topo do corpo
        glPopMatrix()

        # ── Anel de separação superior (cinza escuro) ─────────────────────────
        glColor3f(0.22, 0.22, 0.28)
        glPushMatrix()
        glTranslatef(0, -0.12, 0)
        glRotatef(-90, 1, 0, 0)
        gluCylinder(q, 0.43, 0.43, 0.24, 24, 1)
        glPopMatrix()

        # ── Bay de aviônica / payload (cinza médio) ───────────────────────────
        glColor3f(0.48, 0.50, 0.54)
        glPushMatrix()
        glTranslatef(0, -0.92, 0)
        glRotatef(-90, 1, 0, 0)
        gluCylinder(q, 0.40, 0.40, 0.80, 24, 1)
        gluDisk(q, 0, 0.40, 24, 1)          # fundo
        glTranslatef(0, 0, 0.80)
        gluDisk(q, 0, 0.40, 24, 1)          # topo
        glPopMatrix()

        # ── Anel de separação inferior (cinza escuro) ─────────────────────────
        glColor3f(0.22, 0.22, 0.28)
        glPushMatrix()
        glTranslatef(0, -1.04, 0)
        glRotatef(-90, 1, 0, 0)
        gluCylinder(q, 0.43, 0.43, 0.12, 24, 1)
        glPopMatrix()

        # ── Seção do motor (cinza ardósia) ────────────────────────────────────
        glColor3f(0.30, 0.32, 0.36)
        glPushMatrix()
        glTranslatef(0, -1.76, 0)
        glRotatef(-90, 1, 0, 0)
        gluCylinder(q, 0.40, 0.40, 0.72, 24, 1)
        gluDisk(q, 0, 0.40, 24, 1)          # fundo
        glTranslatef(0, 0, 0.72)
        gluDisk(q, 0, 0.40, 24, 1)          # topo
        glPopMatrix()

        # ── Aletas (4× laranja) fixadas na seção do motor ─────────────────────
        glColor3f(0.95, 0.45, 0.10)
        for ang in (0, 90, 180, 270):
            glPushMatrix()
            glRotatef(ang, 0, 1, 0)
            glTranslatef(0.38, -1.28, 0)
            self._draw_fin()
            glPopMatrix()

        # ── Bocal (negro, forma de sino divergente) ───────────────────────────
        glColor3f(0.12, 0.12, 0.14)
        glPushMatrix()
        glTranslatef(0, -1.76, 0)
        glRotatef(90, 1, 0, 0)              # inverte eixo → cresce para -Y
        gluCylinder(q, 0.20, 0.38, 0.54, 20, 6)
        gluDisk(q, 0, 0.20, 20, 1)          # garganta (topo)
        glPopMatrix()

        gluDeleteQuadric(q)

    def _draw_fin(self):
        """Aleta trapezoidal com sweep traseiro."""
        glBegin(GL_QUADS)
        # face frontal (+Z)
        glNormal3f(0, 0, 1)
        glVertex3f(0.00,  0.00,  0.025)   # raiz superior
        glVertex3f(0.48, -0.42,  0.025)   # ponta — borda de ataque
        glVertex3f(0.34, -1.02,  0.025)   # ponta — borda de fuga
        glVertex3f(0.00, -0.82,  0.025)   # raiz inferior
        # face traseira (-Z)
        glNormal3f(0, 0, -1)
        glVertex3f(0.00,  0.00,  -0.025)
        glVertex3f(0.00, -0.82,  -0.025)
        glVertex3f(0.34, -1.02,  -0.025)
        glVertex3f(0.48, -0.42,  -0.025)
        glEnd()

        # borda de ataque (face lateral esquerda)
        glBegin(GL_QUADS)
        glNormal3f(-1, 0.7, 0)
        glVertex3f(0.00,  0.00,  -0.025)
        glVertex3f(0.00,  0.00,   0.025)
        glVertex3f(0.48, -0.42,   0.025)
        glVertex3f(0.48, -0.42,  -0.025)
        glEnd()

        # borda de fuga (face lateral direita)
        glBegin(GL_QUADS)
        glNormal3f(0.2, -0.5, 0)
        glVertex3f(0.00, -0.82,   0.025)
        glVertex3f(0.34, -1.02,   0.025)
        glVertex3f(0.34, -1.02,  -0.025)
        glVertex3f(0.00, -0.82,  -0.025)
        glEnd()

        # ponta da aleta
        glBegin(GL_QUADS)
        glNormal3f(1, 0, 0)
        glVertex3f(0.48, -0.42,   0.025)
        glVertex3f(0.48, -0.42,  -0.025)
        glVertex3f(0.34, -1.02,  -0.025)
        glVertex3f(0.34, -1.02,   0.025)
        glEnd()

    def _draw_flame(self):
        """Chama animada com triângulos translúcidos saindo do bocal."""
        glEnable(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        glDisable(GL_LIGHTING)

        t  = self._anim_t
        h  = 0.65 + 0.28 * abs(math.sin(t * 1.3))
        w  = 0.18 + 0.06 * abs(math.sin(t * 2.1))
        y0 = -2.30   # saída do bocal

        # Núcleo (branco-amarelo)
        glBegin(GL_TRIANGLES)
        glColor4f(1.0, 0.95, 0.60, 0.95)
        glVertex3f(0,       y0,              0)
        glColor4f(1.0, 0.50, 0.10, 0.0)
        glVertex3f(-w*0.5,  y0 - h*0.6,     0)
        glVertex3f( w*0.5,  y0 - h*0.6,     0)
        glEnd()

        # Envoltura laranja
        glBegin(GL_TRIANGLES)
        glColor4f(1.0, 0.35, 0.00, 0.75)
        glVertex3f(0,       y0,              0)
        glColor4f(1.0, 0.10, 0.00, 0.0)
        glVertex3f(-w,      y0 - h,          0)
        glVertex3f( w,      y0 - h,          0)
        glEnd()

        glEnable(GL_LIGHTING)
        glDisable(GL_BLEND)

    def _draw_hud(self):
        """Sobrepõe texto de estado/telemetria na tela usando renderText."""
        glDisable(GL_LIGHTING)
        glDisable(GL_DEPTH_TEST)

        nome = _ESTADO_NOME.get(self._estado, "?")
        cor  = _ESTADO_COR.get(self._estado, QColor(200, 200, 200))
        self.qglColor(cor)
        self.renderText(8, 18, nome)

        self.qglColor(QColor(80, 210, 130))
        self.renderText(8, 36, f"Alt: {self._altitude:.1f} m")

        self.qglColor(QColor(170, 180, 200))
        self.renderText(8, 52, f"Acel: {self._accel:.1f} m/s²")

        glEnable(GL_DEPTH_TEST)
        glEnable(GL_LIGHTING)

    # ── Drag do mouse para rotação manual ─────────────────────────────────────
    def mousePressEvent(self, e):
        self._last_mouse = e.pos()

    def mouseMoveEvent(self, e):
        if hasattr(self, '_last_mouse'):
            dx = e.x() - self._last_mouse.x()
            dy = e.y() - self._last_mouse.y()
            self._roll  = (self._roll  + dx * 0.5) % 360
            self._pitch = max(-90, min(90, self._pitch - dy * 0.5))
            self._last_mouse = e.pos()
            self.update()
