"""
charts.py — Rigtech Ground Station
Gráficos em tempo real com matplotlib/Qt5Agg.
"""

import time
from collections import deque
import matplotlib
matplotlib.use("Qt5Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from matplotlib.animation import FuncAnimation
from PyQt5.QtWidgets import QWidget, QVBoxLayout

# Paleta
BG     = "#0D1117"
GRID   = "#1E2530"
GREEN  = "#27AE60"
ORANGE = "#F5A623"
WHITE  = "#E8EAF0"
RED    = "#E74C3C"
BLUE   = "#2980B9"

WINDOW_S = 120   # segundos de histórico visível


class RealtimeChart(QWidget):
    """
    Gráfico de linha em tempo real para uma série temporal.
    Parâmetros:
        title, ylabel, color, ylim_min, ylim_max
    """

    def __init__(self, title: str, ylabel: str, color: str,
                 ylim_min: float = None, ylim_max: float = None,
                 parent=None):
        super().__init__(parent)
        self._color    = color
        self._ylim     = (ylim_min, ylim_max)
        self._t0            = None
        self._times         = deque(maxlen=2000)
        self._values        = deque(maxlen=2000)
        self._apogeu_t      = None
        self._inicio_voo_t  = None

        self._fig = Figure(figsize=(5, 2.0), facecolor=BG)
        self._ax  = self._fig.add_subplot(111)
        self._ax.set_facecolor(BG)
        self._ax.set_title(title, color=WHITE, fontsize=9, pad=3)
        self._ax.set_ylabel(ylabel, color=WHITE, fontsize=8)
        self._ax.set_xlabel("Tempo (s)", color=WHITE, fontsize=8)
        self._ax.tick_params(colors=WHITE, labelsize=7)
        for spine in self._ax.spines.values():
            spine.set_edgecolor(GRID)
        self._ax.grid(True, color=GRID, linewidth=0.5, linestyle="--")

        self._line, = self._ax.plot([], [], color=color, linewidth=1.5)
        self._fig.tight_layout(pad=0.8)

        canvas = FigureCanvas(self._fig)
        canvas.setStyleSheet(f"background:{BG};")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(canvas)
        self._canvas = canvas

    # ── API ───────────────────────────────────────────────────────────────────
    def adicionar_ponto(self, valor: float, ts: float = None):
        if ts is None:
            ts = time.time()
        if self._t0 is None:
            self._t0 = ts

        t_rel = ts - self._t0
        self._times.append(t_rel)
        self._values.append(valor)
        self._refresh()

    def marcar_inicio_voo(self, ts: float = None):
        if ts is None:
            ts = time.time()
        if self._t0:
            self._inicio_voo_t = ts - self._t0
        self._refresh()

    def marcar_apogeu(self, ts: float = None):
        if ts is None:
            ts = time.time()
        if self._t0:
            self._apogeu_t = ts - self._t0
        self._refresh()

    def limpar(self):
        self._t0            = None
        self._apogeu_t      = None
        self._inicio_voo_t  = None
        self._times.clear()
        self._values.clear()
        self._line.set_data([], [])
        self._ax.set_xlim(0, 10)
        self._canvas.draw_idle()

    # ── Renderização ──────────────────────────────────────────────────────────
    def _refresh(self):
        if not self._times:
            return

        ts  = list(self._times)
        vs  = list(self._values)
        now = ts[-1]

        # janela deslizante
        x_min = max(0.0, now - WINDOW_S)
        x_max = max(now + 2, 10.0)
        self._ax.set_xlim(x_min, x_max)

        y_vals = [v for t, v in zip(ts, vs) if t >= x_min]
        if y_vals:
            pad = max(1.0, (max(y_vals) - min(y_vals)) * 0.15)
            y_lo = self._ylim[0] if self._ylim[0] is not None else min(y_vals) - pad
            y_hi = self._ylim[1] if self._ylim[1] is not None else max(y_vals) + pad
            self._ax.set_ylim(y_lo, y_hi)

        self._line.set_data(ts, vs)

        # marcadores verticais
        for line in self._ax.lines[1:]:
            line.remove()
        if self._inicio_voo_t is not None:
            self._ax.axvline(self._inicio_voo_t, color=GREEN, linewidth=1.2,
                             linestyle="--", alpha=0.85)
            self._ax.text(self._inicio_voo_t, self._ax.get_ylim()[1],
                          " Decolagem", color=GREEN, fontsize=7, va="top")
        if self._apogeu_t is not None:
            self._ax.axvline(self._apogeu_t, color=RED, linewidth=1.0,
                             linestyle="--", alpha=0.7)
            self._ax.text(self._apogeu_t, self._ax.get_ylim()[1],
                          " Apogeu", color=RED, fontsize=7, va="top")

        self._canvas.draw_idle()


class DualChartPanel(QWidget):
    """Painel com gráfico de altitude + aceleração + distância GPS empilhados."""

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(2)

        self.altitude_chart = RealtimeChart(
            title="Altitude", ylabel="m",
            color=GREEN, ylim_min=0,
        )
        self.accel_chart = RealtimeChart(
            title="Aceleração Total", ylabel="m/s²",
            color=ORANGE, ylim_min=0,
        )
        self.dist_chart = RealtimeChart(
            title="Distância da Base (GPS)", ylabel="m",
            color=BLUE, ylim_min=0,
        )
        self.dr_chart = RealtimeChart(
            title="Distância Estimada (Acelerômetro)", ylabel="m",
            color=ORANGE, ylim_min=0,
        )

        layout.addWidget(self.altitude_chart, stretch=1)
        layout.addWidget(self.accel_chart,    stretch=1)
        layout.addWidget(self.dist_chart,     stretch=1)
        layout.addWidget(self.dr_chart,       stretch=1)

    def adicionar_telemetria(self, altitude: float, aceleracao: float,
                             ts: float = None):
        self.altitude_chart.adicionar_ponto(altitude, ts)
        self.accel_chart.adicionar_ponto(aceleracao, ts)

    def adicionar_gps_dist(self, dist_m: float, ts: float = None):
        self.dist_chart.adicionar_ponto(dist_m, ts)

    def adicionar_dr_dist(self, dist_m: float, ts: float = None):
        self.dr_chart.adicionar_ponto(dist_m, ts)

    def marcar_inicio_voo(self):
        self.altitude_chart.marcar_inicio_voo()
        self.accel_chart.marcar_inicio_voo()
        self.dist_chart.marcar_inicio_voo()
        self.dr_chart.marcar_inicio_voo()

    def marcar_apogeu(self):
        self.altitude_chart.marcar_apogeu()
        self.accel_chart.marcar_apogeu()
        self.dist_chart.marcar_apogeu()
        self.dr_chart.marcar_apogeu()

    def limpar(self):
        self.altitude_chart.limpar()
        self.accel_chart.limpar()
        self.dist_chart.limpar()
        self.dr_chart.limpar()
