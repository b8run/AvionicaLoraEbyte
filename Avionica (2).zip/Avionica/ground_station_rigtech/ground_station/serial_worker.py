"""
serial_worker.py — Rigtech Ground Station
Thread de leitura serial: parseia texto ASCII do Master.ino e emite sinais Qt.
Inclui SimWorker para simulação interna sem porta física.
"""

import time
import math
import serial
import serial.tools.list_ports
from PyQt5.QtCore import QThread, pyqtSignal
from protocol import TelemetryPacket, Resp


def listar_portas():
    """Retorna lista de strings 'COMx - Descrição'."""
    ports = serial.tools.list_ports.comports()
    return [f"{p.device} — {p.description}" for p in ports], \
           [p.device for p in ports]


class SerialWorker(QThread):
    """
    Roda em thread separada.
    Lê texto ASCII do Master.ino e emite pacotes de telemetria para a UI.
    """
    pacote_recebido  = pyqtSignal(object)   # TelemetryPacket
    raw_log          = pyqtSignal(str)       # linha de texto do serial
    status_changed   = pyqtSignal(bool, str)
    erro             = pyqtSignal(str)

    def __init__(self, porta: str, baudrate: int = 115200):
        super().__init__()
        self.porta    = porta
        self.baudrate = baudrate
        self._running = True
        self._serial  = None

    @staticmethod
    def _diagnosticar_erro(porta: str, e: serial.SerialException) -> str:
        msg = str(e)
        if "Access is denied" in msg or "Error 13" in msg or "Errno 13" in msg:
            return (
                f"Acesso negado à porta {porta}.\n"
                "Outra aplicação (Arduino IDE, terminal serial, etc.) "
                "provavelmente está com a porta aberta. Feche-a e tente novamente."
            )
        if (
            "could not open port" in msg
            and ("Error 2" in msg or "Errno 2" in msg or "FileNotFoundError" in msg)
        ):
            return (
                f"Porta {porta} não encontrada.\n"
                "Verifique se o dispositivo está conectado e se o driver "
                "USB-UART (CH340 / CP210x) está instalado."
            )
        return f"Erro ao abrir {porta}: {msg}"

    def run(self):
        try:
            self._serial = serial.Serial(self.porta, self.baudrate, timeout=0.1)
            self.status_changed.emit(True, f"Conectado em {self.porta} @ {self.baudrate}")
        except serial.SerialException as e:
            msg = self._diagnosticar_erro(self.porta, e)
            self.status_changed.emit(False, msg)
            self.erro.emit(msg)
            return

        _buf   = ""          # acumulador de texto
        _state = "idle"      # 'idle' | 'telem' | 'gps'
        _data  = {}          # campos coletados no estado atual

        _ESTADO_MAP = {"AGUARDANDO": 0, "SUBIDA": 1, "DESCIDA": 2, "POUSADO": 3}

        while self._running:
            try:
                raw = self._serial.read(64)
                if not raw:
                    continue

                _buf += raw.decode("latin-1")

                while "\n" in _buf:
                    line, _buf = _buf.split("\n", 1)
                    line = line.rstrip("\r")

                    # Toda linha do Master vai para o log
                    self.raw_log.emit(line)

                    stripped = line.strip()

                    # ── Transições de estado / cabeçalhos ────────────────────
                    if stripped == ">> [TELEMETRIA]":
                        _state = "telem"
                        _data  = {}
                        continue

                    if stripped == ">> [GPS]":
                        _state = "gps"
                        _data  = {}
                        continue

                    if "PONG recebido" in stripped:
                        self.pacote_recebido.emit(
                            TelemetryPacket(int(Resp.PONG), 0, 0.0, 0.0, 0)
                        )
                        _state = "idle"
                        continue

                    if "DOWNLOAD CONCLUIDO" in stripped:
                        self.pacote_recebido.emit(
                            TelemetryPacket(int(Resp.SD_FIM), 0, 0.0, 0.0, 0)
                        )
                        _state = "idle"
                        continue

                    # ── Coleta de campos de telemetria ───────────────────────
                    if _state == "telem":
                        if "Estado" in stripped and ":" in stripped:
                            val = stripped.split(":", 1)[1].strip()
                            _data["contador"] = _ESTADO_MAP.get(val, 0)
                        elif "Altitude" in stripped and ":" in stripped:
                            try:
                                _data["valor1"] = float(
                                    stripped.split(":", 1)[1].strip().split()[0]
                                )
                            except (ValueError, IndexError):
                                pass
                        elif "Aceleracao" in stripped and ":" in stripped:
                            try:
                                _data["valor2"] = float(
                                    stripped.split(":", 1)[1].strip().split()[0]
                                )
                            except (ValueError, IndexError):
                                pass

                        if all(k in _data for k in ("contador", "valor1", "valor2")):
                            self.pacote_recebido.emit(TelemetryPacket(
                                int(Resp.DATA), 0,
                                _data["valor1"], _data["valor2"], _data["contador"]
                            ))
                            _state = "idle"
                            _data  = {}

                    # ── Coleta de campos GPS ──────────────────────────────────
                    elif _state == "gps":
                        if "Latitude" in stripped and ":" in stripped:
                            try:
                                _data["valor1"] = float(
                                    stripped.split(":", 1)[1].strip()
                                )
                            except ValueError:
                                pass
                        elif "Longitude" in stripped and ":" in stripped:
                            try:
                                _data["valor2"] = float(
                                    stripped.split(":", 1)[1].strip()
                                )
                            except ValueError:
                                pass

                        if all(k in _data for k in ("valor1", "valor2")):
                            self.pacote_recebido.emit(TelemetryPacket(
                                int(Resp.GPS), 0,
                                _data["valor1"], _data["valor2"], 0
                            ))
                            _state = "idle"
                            _data  = {}

            except serial.SerialException as e:
                self.status_changed.emit(False, f"Erro serial: {e}")
                break

        if self._serial and self._serial.is_open:
            self._serial.close()
        self.status_changed.emit(False, "Desconectado")

    def enviar(self, data: bytes):
        if self._serial and self._serial.is_open:
            self._serial.write(data)

    def parar(self):
        self._running = False
        self.wait()


# ── Perfil de voo sintético ───────────────────────────────────────────────────
_MOTOR_END = 3.0
_APOGEU    = 10.0
_LAND      = 22.0
_LAT_BASE  = -7.115000
_LON_BASE  = -34.861000


def _sim_voo(t: float):
    if t < 0:
        return 0.0, 9.81, 0
    if t < _MOTOR_END:
        alt = 80 * t - 10 * t**2
        acc = 39.0 + 5 * math.sin(t * 10)
        return max(0.0, alt), acc, 1
    if t < _APOGEU:
        alt0 = 80 * _MOTOR_END - 10 * _MOTOR_END**2
        dt   = t - _MOTOR_END
        alt  = alt0 + 60 * dt - 9.81 / 2 * dt**2
        acc  = max(0.0, 60 - 9.81 * dt) + 1
        return max(0.0, alt), acc, 1
    if t < _LAND:
        alt0 = 80 * _MOTOR_END - 10 * _MOTOR_END**2
        dt_a = _APOGEU - _MOTOR_END
        apog = alt0 + 60 * dt_a - 9.81 / 2 * dt_a**2
        dt   = t - _APOGEU
        return max(0.0, apog - 8 * dt), 10.5, 2
    return 0.0, 9.81, 3


def _sim_gps(t: float):
    drift = min(t / _LAND, 1.0)
    dlat = 0.0027 * drift * math.sin(t * 0.08)
    dlon = 0.0018 * drift * math.cos(t * 0.06)
    return _LAT_BASE + dlat, _LON_BASE + dlon


class SimWorker(QThread):
    """
    Worker de simulação interna — emite os mesmos sinais que SerialWorker.
    Não precisa de porta serial física.
    """
    pacote_recebido = pyqtSignal(object)
    raw_log         = pyqtSignal(str)
    status_changed  = pyqtSignal(bool, str)
    erro            = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self._running = True

    def run(self):
        self.status_changed.emit(True, "Simulação iniciada — voo sintético em andamento")

        t_start  = time.time()
        last_gps = -10.0

        self.pacote_recebido.emit(
            TelemetryPacket(int(Resp.PONG), 0, 0.0, 0.0, 0)
        )

        while self._running:
            t  = time.time() - t_start
            ts = int(t * 1000)
            alt, acc, estado = _sim_voo(t)

            self.raw_log.emit(
                f"[SIM] t={t:.1f}s  alt={alt:.1f}m  "
                f"acc={acc:.1f}m/s²  estado={estado}"
            )
            self.pacote_recebido.emit(
                TelemetryPacket(int(Resp.DATA), ts, alt, acc, estado)
            )

            if t - last_gps >= 10.0:
                lat, lon = _sim_gps(t)
                self.pacote_recebido.emit(
                    TelemetryPacket(int(Resp.GPS), ts, lat, lon, 0)
                )
                last_gps = t

            if estado == 3 and t > _LAND + 10:
                self.status_changed.emit(False, "Simulação concluída — voo encerrado")
                break

            time.sleep(0.75)

    def enviar(self, data: bytes):
        pass

    def parar(self):
        self._running = False
        self.wait()
