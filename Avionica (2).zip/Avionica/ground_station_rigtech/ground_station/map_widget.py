"""
map_widget.py — Rigtech Ground Station
Mapa interativo com satélite offline (contextily / Esri WorldImagery).
Área pré-baixada de 3 km × 3 km ao redor da base de lançamento.
Artists atualizados in-place para preservar zoom/pan do usuário.
"""

import os
import json
import math
import matplotlib
matplotlib.use("Qt5Agg")
from matplotlib.backends.backend_qt5agg import (FigureCanvasQTAgg as FigureCanvas,
                                                 NavigationToolbar2QT)
from matplotlib.figure       import Figure
from matplotlib.ticker       import FuncFormatter
from matplotlib.patheffects  import withStroke
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QFormLayout,
                              QPushButton, QLabel, QDialog, QFrame,
                              QDoubleSpinBox, QDialogButtonBox)
from PyQt5.QtCore    import Qt, QThread, pyqtSignal

try:
    import contextily as ctx
    _TILE_CACHE = os.path.join(os.path.dirname(__file__), ".tile_cache")
    ctx.set_cache_dir(_TILE_CACHE)
    _CTX_OK = True
except ImportError:
    _CTX_OK = False

# ── Paleta ────────────────────────────────────────────────────────────────────
BG     = "#0D1117"
GRID   = "#1E2530"
ACCENT = "#F5A623"
GREEN  = "#27AE60"
RED    = "#E74C3C"
BLUE   = "#2980B9"
WHITE  = "#E8EAF0"
MUTED  = "#6C7A89"

_OUTLINE   = [withStroke(linewidth=2.5, foreground="black")]
_RAIO_M    = 1500          # ±1500 m = 3 km × 3 km
_PREFS     = os.path.join(os.path.dirname(__file__), ".launch_base.json")
_DEF_LAT   = -7.115000
_DEF_LON   = -34.861000


# ── Persistência de coordenadas ───────────────────────────────────────────────
def _load_base():
    try:
        with open(_PREFS) as f:
            d = json.load(f)
        return float(d["lat"]), float(d["lon"])
    except Exception:
        return _DEF_LAT, _DEF_LON


def _save_base(lat: float, lon: float):
    try:
        with open(_PREFS, "w") as f:
            json.dump({"lat": lat, "lon": lon}, f)
    except Exception:
        pass


# ── Conversões geográficas ────────────────────────────────────────────────────
def haversine_m(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    R = 6371000.0
    φ1, φ2 = math.radians(lat1), math.radians(lat2)
    Δφ = math.radians(lat2 - lat1)
    Δλ = math.radians(lon2 - lon1)
    a  = math.sin(Δφ/2)**2 + math.cos(φ1)*math.cos(φ2)*math.sin(Δλ/2)**2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))


def _to_merc(lat: float, lon: float):
    R = 6378137.0
    x = math.radians(lon) * R
    y = math.log(math.tan(math.pi/4 + math.radians(lat)/2)) * R
    return x, y


def _fmt_lon(x, _): return f"{math.degrees(x/6378137.0):.5f}°"
def _fmt_lat(y, _):
    return f"{math.degrees(2*math.atan(math.exp(y/6378137.0))-math.pi/2):.5f}°"


# ── Dialog de base de lançamento ──────────────────────────────────────────────
class _BaseDialog(QDialog):
    def __init__(self, lat: float, lon: float, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Base de Lançamento")
        self.setFixedWidth(310)
        self.setStyleSheet(
            f"QDialog   {{ background:{BG}; }}"
            f"QLabel    {{ color:{WHITE}; font-size:11px; }}"
            f"QDoubleSpinBox {{ background:#141c28; color:{WHITE}; "
            f"  border:1px solid {GRID}; border-radius:4px; padding:3px 6px; }}"
        )

        root = QVBoxLayout(self)
        root.setSpacing(10)
        root.setContentsMargins(16, 14, 16, 14)

        tit = QLabel("📍  Definir Base de Lançamento")
        tit.setStyleSheet(f"color:{ACCENT}; font-weight:700; font-size:13px;")
        root.addWidget(tit)

        sep = QFrame(); sep.setFrameShape(QFrame.HLine)
        sep.setStyleSheet(f"color:{GRID};"); root.addWidget(sep)

        form = QFormLayout()
        form.setSpacing(8)
        form.setLabelAlignment(Qt.AlignRight)

        self._lat = QDoubleSpinBox()
        self._lat.setRange(-90, 90); self._lat.setDecimals(6)
        self._lat.setValue(lat); self._lat.setSuffix(" °")

        self._lon = QDoubleSpinBox()
        self._lon.setRange(-180, 180); self._lon.setDecimals(6)
        self._lon.setValue(lon); self._lon.setSuffix(" °")

        form.addRow("Latitude:", self._lat)
        form.addRow("Longitude:", self._lon)
        root.addLayout(form)

        btn_sim = QPushButton("Usar coordenadas de simulação")
        btn_sim.setStyleSheet(
            f"background:#1a2535; color:{MUTED}; border:1px solid {GRID};"
            f"border-radius:4px; padding:3px; font-size:10px;"
        )
        btn_sim.clicked.connect(lambda: (
            self._lat.setValue(_DEF_LAT), self._lon.setValue(_DEF_LON)))
        root.addWidget(btn_sim)

        row = QHBoxLayout()
        btn_cancel = QPushButton("Cancelar")
        btn_cancel.setStyleSheet(
            f"background:#1E2530; color:{MUTED}; border:1px solid {GRID}; border-radius:4px; padding:4px 14px;")
        btn_cancel.clicked.connect(self.reject)

        btn_ok = QPushButton("Confirmar")
        btn_ok.setStyleSheet(
            f"background:{GREEN}33; color:{GREEN}; border:1px solid {GREEN}66; border-radius:4px; padding:4px 14px; font-weight:700;")
        btn_ok.clicked.connect(self.accept)
        btn_ok.setDefault(True)

        row.addWidget(btn_cancel)
        row.addStretch()
        row.addWidget(btn_ok)
        root.addLayout(row)

    @property
    def lat(self): return self._lat.value()
    @property
    def lon(self): return self._lon.value()


# ── Thread de download de tiles ───────────────────────────────────────────────
class _TileLoader(QThread):
    concluido = pyqtSignal(object, object)
    falhou    = pyqtSignal(str)

    def __init__(self, x0: float, y0: float, raio: int = _RAIO_M, zoom: int = 16):
        super().__init__()
        self._x0, self._y0, self._raio, self._zoom = x0, y0, raio, zoom

    def run(self):
        try:
            img, ext = ctx.bounds2img(
                self._x0 - self._raio, self._y0 - self._raio,
                self._x0 + self._raio, self._y0 + self._raio,
                zoom=self._zoom,
                source=ctx.providers.Esri.WorldImagery,
                ll=False,
            )
            self.concluido.emit(img, ext)
        except Exception as e:
            self.falhou.emit(str(e))


# ── Toolbar customizada ───────────────────────────────────────────────────────
class _Toolbar(NavigationToolbar2QT):
    toolitems = [t for t in NavigationToolbar2QT.toolitems
                 if t[0] in ("Home", "Pan", "Zoom", "Save")]


# ── Widget principal ──────────────────────────────────────────────────────────
class MapWidget(QWidget):

    # Emitido quando a base é definida manualmente (lat, lon)
    base_definida = pyqtSignal(float, float)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._lat_launch = self._lon_launch = None
        self._x0 = self._y0 = None
        self._lat_land = self._lon_land = None
        self._gps_pts    = []
        self._trajetoria = []
        self._satelite   = False
        self._sat_img    = None
        self._sat_ext    = None
        self._tile_loader: _TileLoader = None
        self._art: dict  = {}
        self._ax_ready   = False

        self._build_ui()
        self._draw_empty()

    # ── UI ────────────────────────────────────────────────────────────────────
    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(2)

        bar = QHBoxLayout()
        bar.setContentsMargins(4, 2, 4, 2)

        self._lbl_status = QLabel("Aguardando GPS…")
        self._lbl_status.setStyleSheet(f"color:{ACCENT}; font-size:11px;")
        bar.addWidget(self._lbl_status)
        bar.addStretch()

        # Botão Base
        btn_base = QPushButton("📍 Base")
        btn_base.setFixedWidth(76)
        btn_base.setToolTip("Pré-definir coordenadas da base de lançamento")
        btn_base.setStyleSheet(
            f"QPushButton {{ background:#1E2530; color:{ACCENT}; border:1px solid {ACCENT}55;"
            f"border-radius:4px; padding:2px 6px; }}"
            f"QPushButton:hover {{ background:{ACCENT}22; }}"
        )
        btn_base.clicked.connect(self._definir_base)
        bar.addWidget(btn_base)

        # Botão Satélite
        self._btn_sat = QPushButton("🛰 Satélite")
        self._btn_sat.setCheckable(True)
        self._btn_sat.setFixedWidth(90)
        self._btn_sat.setStyleSheet(self._sat_style(False))
        self._btn_sat.clicked.connect(self._toggle_sat)
        if not _CTX_OK:
            self._btn_sat.setEnabled(False)
            self._btn_sat.setToolTip("pip install contextily")
        bar.addWidget(self._btn_sat)

        btn_lp = QPushButton("Limpar")
        btn_lp.setFixedWidth(64)
        btn_lp.clicked.connect(self.limpar)
        btn_lp.setStyleSheet(
            f"background:#1E2530; color:{WHITE}; border:1px solid #333; border-radius:4px; padding:2px 4px;")
        bar.addWidget(btn_lp)
        layout.addLayout(bar)

        # Canvas + toolbar
        self._fig    = Figure(figsize=(5, 5), facecolor=BG)
        self._ax     = self._fig.add_subplot(111)
        self._canvas = FigureCanvas(self._fig)
        self._canvas.setStyleSheet(f"background:{BG};")

        self._toolbar = _Toolbar(self._canvas, self)
        self._toolbar.setStyleSheet(
            f"QToolBar {{ background:#13191F; spacing:2px; border:none; border-bottom:1px solid {GRID}; }}"
            f"QToolButton {{ background:#1E2530; color:{WHITE}; padding:3px 6px;"
            f"border:1px solid #2a3040; border-radius:3px; margin:2px; }}"
            f"QToolButton:checked {{ background:#0d2010; border-color:{GREEN}; color:{GREEN}; }}"
            f"QToolButton:hover   {{ background:#252d3d; }}"
        )
        layout.addWidget(self._toolbar)
        layout.addWidget(self._canvas, stretch=1)

        # Legenda
        leg = QHBoxLayout()
        leg.setContentsMargins(6, 0, 6, 2)
        for cor, txt in [(ACCENT, "Lançamento"), (GREEN, "Trajetória"),
                         (RED, "Pouso"), (BLUE, "GPS")]:
            dot = QLabel("●")
            dot.setStyleSheet(f"color:{cor}; font-size:12px;")
            lbl = QLabel(txt)
            lbl.setStyleSheet(f"color:{WHITE}; font-size:9px;")
            leg.addWidget(dot); leg.addWidget(lbl); leg.addSpacing(6)
        leg.addStretch()
        layout.addLayout(leg)

    @staticmethod
    def _sat_style(on: bool) -> str:
        if on:
            return (f"QPushButton {{ background:#0d2b0d; color:{GREEN};"
                    f"border:1px solid {GREEN}; border-radius:4px; padding:2px 6px; }}")
        return (f"QPushButton {{ background:#1E2530; color:{WHITE};"
                f"border:1px solid #444; border-radius:4px; padding:2px 6px; }}"
                f"QPushButton:hover {{ background:#252d3d; }}")

    # ── Base de lançamento manual ─────────────────────────────────────────────
    def _definir_base(self):
        lat0, lon0 = _load_base()
        d = _BaseDialog(lat0, lon0, parent=self)
        if d.exec_() != QDialog.Accepted:
            return

        lat, lon = d.lat, d.lon
        _save_base(lat, lon)

        # Reset completo se já havia uma base definida
        if self._lat_launch is not None:
            self._art.clear()
            self._gps_pts.clear()
            self._trajetoria.clear()
            self._lat_land = self._lon_land = None
            self._sat_img  = self._sat_ext  = None
            self._ax_ready = False

        self._lat_launch = lat
        self._lon_launch = lon
        self._x0, self._y0 = _to_merc(lat, lon)

        self._init_axes()
        self._place_launch_marker()

        # Pré-download de tiles independente do toggle de satélite
        if _CTX_OK:
            self._lbl_status.setText("⏳ Pré-baixando tiles 3 km × 3 km…")
            self._start_tile_download()

        self._canvas.draw()
        self.base_definida.emit(lat, lon)

    # ── API pública ───────────────────────────────────────────────────────────
    def set_launch(self, lat: float, lon: float):
        """Chamado quando o primeiro GPS chega (via main_window)."""
        if self._lat_launch is None:
            self._lat_launch = lat
            self._lon_launch = lon
            self._x0, self._y0 = _to_merc(lat, lon)
            self._init_axes()
            self._place_launch_marker()
            if _CTX_OK and self._satelite:
                self._start_tile_download()
        self._canvas.draw()

    def add_gps_point(self, lat: float, lon: float):
        self._gps_pts.append(_to_merc(lat, lon))
        self._lbl_status.setText(f"GPS: {lat:.6f}°, {lon:.6f}°")
        self._update_gps_scatter()
        self._canvas.draw()

    def add_telemetry_point(self, lat: float, lon: float, alt: float, estado: int):
        self._trajetoria.append((*_to_merc(lat, lon), alt, estado))
        self._update_trajectory()
        self._canvas.draw()

    def set_landing(self, lat: float, lon: float):
        self._lat_land = lat
        self._lon_land = lon
        if self._lat_launch:
            d = haversine_m(self._lat_launch, self._lon_launch, lat, lon)
            self._lbl_status.setText(
                f"🏁 Pouso: {lat:.6f}°, {lon:.6f}° | Δ {d:.0f} m da base")
        self._place_land_marker()
        self._canvas.draw()

    def limpar(self):
        self._lat_launch = self._lon_launch = None
        self._x0 = self._y0 = None
        self._lat_land = self._lon_land = None
        self._gps_pts.clear()
        self._trajetoria.clear()
        self._sat_img = self._sat_ext = None
        self._art.clear()
        self._ax_ready = False
        self._lbl_status.setText("Aguardando GPS…")
        self._draw_empty()

    # ── Inicialização dos eixos ───────────────────────────────────────────────
    def _init_axes(self):
        ax = self._ax
        ax.clear()
        ax.set_facecolor(BG)
        for sp in ax.spines.values(): sp.set_edgecolor(GRID)
        ax.tick_params(colors=WHITE, labelsize=7)
        ax.xaxis.set_major_formatter(FuncFormatter(_fmt_lon))
        ax.yaxis.set_major_formatter(FuncFormatter(_fmt_lat))
        ax.grid(True, color=GRID, linewidth=0.5, linestyle="--", zorder=1)
        ax.set_xlabel("Longitude", color=WHITE, fontsize=8)
        ax.set_ylabel("Latitude",  color=WHITE, fontsize=8)
        ax.set_title("Trajetória de Voo", color=WHITE, fontsize=9, pad=4)
        R = _RAIO_M
        ax.set_xlim(self._x0 - R, self._x0 + R)
        ax.set_ylim(self._y0 - R, self._y0 + R)
        self._ax_ready = True
        self._toolbar.update()

    # ── Gestão de artists in-place ────────────────────────────────────────────
    def _rm(self, key: str):
        a = self._art.pop(key, None)
        if a is None: return
        for item in (a if isinstance(a, (list, tuple)) else [a]):
            try: item.remove()
            except Exception: pass

    def _place_launch_marker(self):
        if not self._ax_ready: return
        self._rm("launch")
        ax = self._ax
        sc = ax.scatter(self._x0, self._y0, color=ACCENT, s=160, zorder=6,
                        marker="^", edgecolors="black", linewidths=0.8)
        an = ax.annotate("  LANÇAMENTO", (self._x0, self._y0), color=ACCENT,
                         fontsize=8, fontweight="bold", va="center", zorder=7)
        self._art["launch"] = (sc, an)

    def _place_land_marker(self):
        if not self._ax_ready or self._lat_land is None: return
        self._rm("land")
        ax  = self._ax
        xl, yl = _to_merc(self._lat_land, self._lon_land)
        sat_on = self._satelite and "sat" in self._art

        # Estrela vermelha com círculo — bem visível sobre satélite
        circle = ax.scatter(xl, yl, color=RED, s=420, zorder=6,
                            marker="o", edgecolors="white", linewidths=1.2, alpha=0.35)
        star   = ax.scatter(xl, yl, color=RED, s=200, zorder=7,
                            marker="*", edgecolors="black", linewidths=0.6)
        an = ax.annotate("  POUSO", (xl, yl), color=RED,
                         fontsize=9, fontweight="bold", va="center", zorder=8)
        if sat_on:
            an.set_path_effects(_OUTLINE)
        self._art["land"] = (circle, star, an)

    def _update_trajectory(self):
        if not self._ax_ready: return
        self._rm("traj")
        if len(self._trajetoria) < 2: return
        xs = [p[0] for p in self._trajetoria]
        ys = [p[1] for p in self._trajetoria]
        line, = self._ax.plot(xs, ys, color=GREEN, linewidth=1.8,
                              alpha=0.9, zorder=3, solid_capstyle="round")
        self._art["traj"] = line

    def _update_gps_scatter(self):
        if not self._ax_ready or not self._gps_pts: return
        self._rm("gps")
        gx, gy = zip(*self._gps_pts)
        sc = self._ax.scatter(gx, gy, color=BLUE, s=32, zorder=4,
                              edgecolors="white", linewidths=0.3, alpha=0.9)
        self._art["gps"] = sc

    # ── Satélite ──────────────────────────────────────────────────────────────
    def _toggle_sat(self, checked: bool):
        self._satelite = checked
        self._btn_sat.setStyleSheet(self._sat_style(checked))
        if checked:
            if self._sat_img is not None:
                self._apply_sat_image()
            elif self._x0 is not None and _CTX_OK:
                self._start_tile_download()
        else:
            self._rm("sat")
            self._apply_dark_style()
        self._canvas.draw()

    def _start_tile_download(self):
        if self._tile_loader and self._tile_loader.isRunning(): return
        self._tile_loader = _TileLoader(self._x0, self._y0)
        self._tile_loader.concluido.connect(self._on_tiles_ok)
        self._tile_loader.falhou.connect(self._on_tiles_fail)
        self._tile_loader.start()

    def _on_tiles_ok(self, img, ext):
        self._sat_img = img
        self._sat_ext = ext
        if self._satelite:
            self._apply_sat_image()
            self._canvas.draw()
        self._lbl_status.setText("✓ Tiles prontos — 3 km × 3 km (Esri WorldImagery)")

    def _on_tiles_fail(self, msg: str):
        self._lbl_status.setText("⚠ Tiles indisponíveis (sem cache / internet)")
        self._btn_sat.setChecked(False)
        self._satelite = False
        self._btn_sat.setStyleSheet(self._sat_style(False))

    def _apply_sat_image(self):
        self._rm("sat")
        if not self._ax_ready or self._sat_img is None: return
        artist = self._ax.imshow(self._sat_img, extent=self._sat_ext,
                                 interpolation="bilinear", aspect="auto", zorder=0)
        self._art["sat"] = artist
        self._apply_sat_style()
        self._place_launch_marker()
        if self._lat_land: self._place_land_marker()

    def _apply_sat_style(self):
        ax = self._ax
        ax.set_facecolor("white")
        for sp in ax.spines.values(): sp.set_edgecolor("#888")
        ax.tick_params(colors="#222")
        ax.xaxis.label.set_color("#222")
        ax.yaxis.label.set_color("#222")
        ax.title.set_color("#111")
        ax.grid(True, color="#ccc", linewidth=0.4, linestyle="--", zorder=1)

    def _apply_dark_style(self):
        ax = self._ax
        ax.set_facecolor(BG)
        for sp in ax.spines.values(): sp.set_edgecolor(GRID)
        ax.tick_params(colors=WHITE)
        ax.xaxis.label.set_color(WHITE)
        ax.yaxis.label.set_color(WHITE)
        ax.title.set_color(WHITE)
        ax.grid(True, color=GRID, linewidth=0.5, linestyle="--", zorder=1)
        self._place_launch_marker()
        if self._lat_land: self._place_land_marker()

    def _draw_empty(self):
        ax = self._ax
        ax.clear()
        ax.set_facecolor(BG)
        ax.set_xlim(-1, 1); ax.set_ylim(-1, 1)
        for sp in ax.spines.values(): sp.set_edgecolor(GRID)
        ax.tick_params(colors=WHITE, labelsize=7)
        ax.text(0, 0, "Aguardando GPS... (ou clique em [Base])",
                ha="center", va="center", color=ACCENT,
                fontsize=10, style="italic", alpha=0.6)
        ax.grid(True, color=GRID, linewidth=0.5, linestyle="--")
        self._fig.tight_layout(pad=1.2)
        self._canvas.draw()

    def redraw(self):
        pass
