"""
simulate.py — Rigtech Ground Station
Simulador de telemetria: cria uma porta serial virtual e envia
pacotes realistas para testar a UI sem hardware.

Uso (Windows com com0com instalado, ou Linux com socat):
    # Linux:
    socat PTY,link=/tmp/FOGUETE,raw,echo=0 PTY,link=/tmp/BASE,raw,echo=0 &
    python simulate.py --port /tmp/FOGUETE &
    python main.py   --port /tmp/BASE    (configurar na UI)

    # Modo standalone (imprime na stdout para verificação):
    python simulate.py --dry-run

Sem socat, use para verificar os bytes gerados:
    python simulate.py --dry-run
"""

import sys
import time
import math
import struct
import argparse

# ── Protocolo (inline, sem importar do módulo que usa Qt) ─────────────────────
RESP_DATA   = 10
RESP_GPS    = 11
RESP_PONG   = 12
RESP_SD_FIM = 14

RESPONSE_FMT  = "<BBBBff8s"
RESPONSE_SIZE = struct.calcsize(RESPONSE_FMT)

def _pack(resp, contador, v1, v2, payload=b"\x00"*8):
    return struct.pack(RESPONSE_FMT, resp, contador, 0, 0, v1, v2, payload)

# ── Perfil de voo sintético ───────────────────────────────────────────────────
def _altitude(t: float) -> tuple[float, float, int]:
    """Retorna (altitude, aceleracao_m_s2, estado)."""
    MOTOR_END  = 3.0
    APOGEU     = 10.0
    LAND       = 22.0

    if t < 0:
        return 0.0, 9.81, 0      # AGUARDANDO

    if t < MOTOR_END:
        # subida com motor — aceleração ~4g
        alt = 80 * t - 10 * t**2
        acc = 39.0 + 5 * math.sin(t * 10)
        return max(0, alt), acc, 1    # SUBIDA

    if t < APOGEU:
        # subida livre — desaceleração
        alt_at_cutoff = 80 * MOTOR_END - 10 * MOTOR_END**2  # inline sem recursão
        dt  = t - MOTOR_END
        alt = alt_at_cutoff + 60 * dt - 9.81/2 * dt**2
        acc = max(0, 60 - 9.81 * dt)
        return max(0, alt), acc + 1, 1

    if t < LAND:
        # descida paraquedas — calcular apogeu diretamente
        _mc = 80 * MOTOR_END - 10 * MOTOR_END**2
        _dt_ap = APOGEU - MOTOR_END
        alt_apogeu = _mc + 60 * _dt_ap - 9.81/2 * _dt_ap**2
        dt  = t - APOGEU
        alt = max(0, alt_apogeu - 8 * dt)
        return alt, 10.5, 2    # DESCIDA  (accel ~1g com paraquedas)

    return 0.0, 9.81, 3    # POUSADO

# Coordenadas simuladas (base + desvio)
LAT_BASE =  -7.115000
LON_BASE = -34.861000

def _gps(t):
    drift_lat = 0.0001 * math.sin(t * 0.1)
    drift_lon = 0.0001 * math.cos(t * 0.1)
    return LAT_BASE + drift_lat, LON_BASE + drift_lon


def run(port: str | None, dry_run: bool):
    ser = None
    if not dry_run:
        import serial
        ser = serial.Serial(port, 115200)
        print(f"[SIM] Enviando para {port}")
    else:
        print(f"[SIM] Modo dry-run — bytes impressos na stdout")

    t_start = time.time()
    last_gps = 0.0

    try:
        while True:
            t = time.time() - t_start
            alt, acc, estado = _altitude(t)

            # Pacote DATA a ~750ms
            data = _pack(RESP_DATA, estado, alt, acc)
            if dry_run:
                print(f"t={t:.1f}s  {RESP_DATA}  alt={alt:.1f}m  acc={acc:.1f}m/s²  "
                      f"estado={estado}  hex={data.hex()}")
            else:
                ser.write(data)

            # GPS a cada ~10s
            if t - last_gps >= 10.0:
                lat, lon = _gps(t)
                gps_data = _pack(RESP_GPS, 0, lat, lon)
                if dry_run:
                    print(f"t={t:.1f}s  GPS  lat={lat:.6f}  lon={lon:.6f}")
                else:
                    ser.write(gps_data)
                last_gps = t

            # PONG espontâneo ao iniciar
            if t < 0.1:
                pong = _pack(RESP_PONG, 0, 0, 0)
                if not dry_run:
                    ser.write(pong)

            # Fim após pouso
            if estado == 3 and t > 25:
                print("[SIM] Voo concluído.")
                break

            time.sleep(0.75)

    except KeyboardInterrupt:
        print("\n[SIM] Interrompido.")
    finally:
        if ser:
            ser.close()


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--port",     default=None)
    ap.add_argument("--dry-run",  action="store_true")
    args = ap.parse_args()

    if not args.dry_run and not args.port:
        print("Use --port COMx ou --dry-run")
        sys.exit(1)

    run(args.port, args.dry_run)
