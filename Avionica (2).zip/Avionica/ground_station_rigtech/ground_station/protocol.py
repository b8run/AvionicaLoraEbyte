"""
protocol.py — Rigtech Foguete V1
Espelha LoRaProtocol.h: comandos, respostas e parsing de pacotes.
"""

from dataclasses import dataclass
from enum import IntEnum

# ── Comandos enviados ao foguete ──────────────────────────────────────────────
class Cmd(IntEnum):
    READ         = 1
    PING         = 2
    ARMAR        = 3
    RESET_BASE   = 4
    GET_GPS      = 5
    DOWNLOAD_SD  = 6

# ── Tipos de resposta do foguete ──────────────────────────────────────────────
class Resp(IntEnum):
    DATA    = 1
    PONG    = 2
    GPS     = 3
    SD_FIM  = 4

# ── Estado de voo ─────────────────────────────────────────────────────────────
class EstadoVoo(IntEnum):
    AGUARDANDO = 0
    SUBIDA     = 1
    DESCIDA    = 2
    POUSADO    = 3

ESTADO_LABEL = {
    EstadoVoo.AGUARDANDO: "AGUARDANDO",
    EstadoVoo.SUBIDA:     "SUBIDA",
    EstadoVoo.DESCIDA:    "DESCIDA",
    EstadoVoo.POUSADO:    "POUSADO",
}

ESTADO_COR = {
    EstadoVoo.AGUARDANDO: "#F5A623",
    EstadoVoo.SUBIDA:     "#27AE60",
    EstadoVoo.DESCIDA:    "#27AE60",
    EstadoVoo.POUSADO:    "#E74C3C",
}

# Comandos como texto ASCII — o Master.ino lê via Serial.readStringUntil('\n')
_CMD_TEXT = {
    Cmd.READ:        b"READ\n",
    Cmd.PING:        b"PING\n",
    Cmd.ARMAR:       b"ARMAR\n",
    Cmd.RESET_BASE:  b"RESET\n",
    Cmd.GET_GPS:     b"GPS\n",
    Cmd.DOWNLOAD_SD: b"SD\n",
}


def build_command(cmd: Cmd) -> bytes:
    return _CMD_TEXT[cmd]


@dataclass
class TelemetryPacket:
    resp:      int
    timestamp: int    # ms desde boot (0 se indisponível)
    valor1:    float
    valor2:    float
    contador:  int    # estado de voo (RESP_DATA) ou 0

    @property
    def estado(self) -> EstadoVoo:
        try:
            return EstadoVoo(self.contador)
        except ValueError:
            return EstadoVoo.AGUARDANDO

    @property
    def altitude(self) -> float:
        return self.valor1

    @property
    def aceleracao(self) -> float:
        return self.valor2

    @property
    def latitude(self) -> float:
        return self.valor1

    @property
    def longitude(self) -> float:
        return self.valor2
