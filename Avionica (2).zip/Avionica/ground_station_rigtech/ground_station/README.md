# Rigtech Ground Station — Foguete V1

Estação base de telemetria para o Foguete V1 do projeto Rigtech.

## Instalação

```bash
pip install -r requirements.txt
```

## Uso

```bash
python main.py
```

1. Selecione a porta COM do Master ESP32 no dropdown
2. Clique **CONECTAR**
3. Envie **PING** para verificar link RF
4. Acompanhe telemetria nas abas Gráficos e Mapa

## Testar sem hardware (simulador)

```bash
# Verifica os pacotes gerados (sem porta serial)
python simulate.py --dry-run

# Com porta virtual (Windows + com0com, ou Linux + socat)
python simulate.py --port COM3
```

## Arquivos

| Arquivo | Descrição |
|---|---|
| `main.py` | Entrypoint |
| `main_window.py` | Janela principal (integração) |
| `protocol.py` | Protocolo de comunicação (espelha LoRaProtocol.h) |
| `serial_worker.py` | Thread de leitura serial |
| `rocket_3d.py` | Visualizador 3D OpenGL |
| `map_widget.py` | Mapa 2D offline (matplotlib) |
| `charts.py` | Gráficos tempo real (altitude + aceleração) |
| `telemetry_panel.py` | Painel de valores numéricos |
| `command_panel.py` | Barra de comandos + log |
| `simulate.py` | Simulador de voo para testes |

## Comandos disponíveis

| Botão | Comando | Ação |
|---|---|---|
| PING | CMD_PING | Testa link RF |
| READ | CMD_READ | Solicita telemetria imediata |
| GPS | CMD_GET_GPS | Solicita coordenadas GPS |
| RESET | CMD_RESET_BASE | Recalibra altímetro |
| SD | CMD_DOWNLOAD_SD | Baixa log do cartão SD |
| ARMAR | CMD_ARMAR | ⚠ Força estado SUBIDA (pede confirmação) |

## Estrutura do pacote `Response` (20 bytes)

```c
struct Response {
  uint8_t resp;       // tipo de resposta
  uint8_t contador;   // estado de voo (em RESP_DATA)
  uint8_t pad[2];
  float   valor1;     // altitude ou latitude
  float   valor2;     // aceleração ou longitude
  uint8_t payload[8]; // bloco SD
};
```
