"""
command_panel.py — Rigtech Ground Station
Barra de comandos: conectar serial + botões de envio de comandos.
"""

from PyQt5.QtWidgets import (QWidget, QHBoxLayout, QVBoxLayout, QPushButton,
                              QComboBox, QLabel, QMessageBox, QFrame,
                              QTextEdit, QSizePolicy)
from PyQt5.QtCore    import Qt, pyqtSignal
from PyQt5.QtGui     import QFont, QColor
from protocol        import Cmd

BG      = "#0D1117"
CARD    = "#13191F"
BORDER  = "#1E2530"
WHITE   = "#E8EAF0"
MUTED   = "#6C7A89"
GREEN   = "#27AE60"
ORANGE  = "#F5A623"
RED     = "#E74C3C"
BLUE    = "#2980B9"


def _btn(text: str, color: str, width: int = 90) -> QPushButton:
    b = QPushButton(text)
    b.setFixedSize(width, 34)
    b.setFont(QFont("Consolas", 9, QFont.Bold))
    b.setStyleSheet(
        f"QPushButton {{ background:{color}22; color:{color};"
        f"border:1px solid {color}55; border-radius:5px; }}"
        f"QPushButton:hover {{ background:{color}44; }}"
        f"QPushButton:pressed {{ background:{color}66; }}"
        f"QPushButton:disabled {{ background:#111; color:#333; border-color:#222; }}"
    )
    return b


class CommandPanel(QWidget):
    """
    Barra superior: seleção de porta + botões de comando.
    Emite sinais para a janela principal.
    """
    sig_conectar     = pyqtSignal(str, int)   # porta, baudrate
    sig_desconectar  = pyqtSignal()
    sig_simular      = pyqtSignal()           # inicia SimWorker interno
    sig_comando      = pyqtSignal(int)         # Cmd value
    sig_limpar_log   = pyqtSignal()
    sig_exportar_csv = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(58)
        self.setStyleSheet(
            f"background:{CARD}; border-bottom:1px solid {BORDER};"
        )
        self._conectado = False

        lay = QHBoxLayout(self)
        lay.setContentsMargins(10, 6, 10, 6)
        lay.setSpacing(8)

        # ── Porta serial ──────────────────────────────────────────────────────
        self._porta_cb = QComboBox()
        self._porta_cb.setFixedWidth(160)
        self._porta_cb.setStyleSheet(
            f"background:#0D1117; color:{WHITE}; border:1px solid {BORDER};"
            f"border-radius:4px; padding:2px 6px; font-size:11px;"
        )
        lay.addWidget(QLabel("Porta:"))
        lay.addWidget(self._porta_cb)

        self._baud_cb = QComboBox()
        self._baud_cb.addItems(["115200", "9600", "57600", "38400"])
        self._baud_cb.setFixedWidth(80)
        self._baud_cb.setStyleSheet(self._porta_cb.styleSheet())
        lay.addWidget(self._baud_cb)

        self._btn_refresh = _btn("↺", WHITE, 34)
        self._btn_refresh.setToolTip("Atualizar portas")
        self._btn_refresh.clicked.connect(self._atualizar_portas)
        lay.addWidget(self._btn_refresh)

        self._btn_conn = _btn("CONECTAR", GREEN, 100)
        self._btn_conn.clicked.connect(self._toggle_conexao)
        lay.addWidget(self._btn_conn)

        self._btn_sim = _btn("▶ SIMULAR", ORANGE, 100)
        self._btn_sim.setToolTip("Simula voo completo sem hardware")
        self._btn_sim.clicked.connect(self._toggle_simulacao)
        lay.addWidget(self._btn_sim)

        sep = QFrame(); sep.setFrameShape(QFrame.VLine)
        sep.setStyleSheet(f"color:{BORDER};")
        lay.addWidget(sep)

        # ── Comandos de voo ───────────────────────────────────────────────────
        cmd_specs = [
            ("PING",  BLUE,   Cmd.PING,        "Testa a conexão RF"),
            ("READ",  GREEN,  Cmd.READ,        "Solicita telemetria"),
            ("GPS",   BLUE,   Cmd.GET_GPS,     "Solicita coordenadas GPS"),
            ("RESET", ORANGE, Cmd.RESET_BASE,  "Recalcula altitude base"),
            ("SD",    MUTED,  Cmd.DOWNLOAD_SD, "Baixa log do SD card"),
            ("ARMAR", RED,    Cmd.ARMAR,       "⚠ Força estado SUBIDA"),
        ]

        self._cmd_btns = {}
        for label, cor, cmd, tip in cmd_specs:
            b = _btn(label, cor)
            b.setToolTip(tip)
            b.setEnabled(False)
            if cmd == Cmd.ARMAR:
                b.clicked.connect(lambda _, c=cmd: self._confirmar_armar(c))
            else:
                b.clicked.connect(lambda _, c=cmd: self.sig_comando.emit(int(c)))
            self._cmd_btns[cmd] = b
            lay.addWidget(b)

        lay.addStretch()

        # ── Ações de sessão ───────────────────────────────────────────────────
        btn_exp = _btn("CSV", ORANGE, 60)
        btn_exp.setToolTip("Exportar sessão como CSV")
        btn_exp.clicked.connect(self.sig_exportar_csv.emit)
        lay.addWidget(btn_exp)

        btn_clr = _btn("Limpar", MUTED, 70)
        btn_clr.clicked.connect(self.sig_limpar_log.emit)
        lay.addWidget(btn_clr)

        self._atualizar_portas()

    # ── Conexão ───────────────────────────────────────────────────────────────
    def _atualizar_portas(self):
        self._porta_cb.clear()
        from serial_worker import listar_portas
        labels, devices = listar_portas()
        if labels:
            for l in labels:
                self._porta_cb.addItem(l)
            self._porta_cb.setProperty("devices", devices)
        else:
            self._porta_cb.addItem("Nenhuma porta encontrada")
            self._porta_cb.setProperty("devices", [])

    def _toggle_conexao(self):
        if not self._conectado:
            devices = self._porta_cb.property("devices") or []
            idx = self._porta_cb.currentIndex()
            if not devices or idx < 0 or idx >= len(devices):
                QMessageBox.warning(self, "Erro", "Nenhuma porta serial disponível.")
                return
            porta   = devices[idx]
            baud    = int(self._baud_cb.currentText())
            self.sig_conectar.emit(porta, baud)
        else:
            self.sig_desconectar.emit()

    def _toggle_simulacao(self):
        if not self._conectado:
            self.sig_simular.emit()
        else:
            self.sig_desconectar.emit()

    def set_conectado(self, ok: bool):
        self._conectado = ok
        # Botão CONECTAR
        self._btn_conn.setText("DESCONECTAR" if ok else "CONECTAR")
        cor_conn = RED if ok else GREEN
        self._btn_conn.setStyleSheet(
            f"QPushButton {{ background:{cor_conn}22; color:{cor_conn};"
            f"border:1px solid {cor_conn}55; border-radius:5px; }}"
            f"QPushButton:hover {{ background:{cor_conn}44; }}"
        )
        # Botão SIMULAR
        if ok:
            self._btn_sim.setText("■ PARAR SIM")
            self._btn_sim.setStyleSheet(
                f"QPushButton {{ background:{RED}22; color:{RED};"
                f"border:1px solid {RED}55; border-radius:5px; }}"
                f"QPushButton:hover {{ background:{RED}44; }}"
            )
        else:
            self._btn_sim.setText("▶ SIMULAR")
            self._btn_sim.setStyleSheet(
                f"QPushButton {{ background:{ORANGE}22; color:{ORANGE};"
                f"border:1px solid {ORANGE}55; border-radius:5px; }}"
                f"QPushButton:hover {{ background:{ORANGE}44; }}"
                f"QPushButton:pressed {{ background:{ORANGE}66; }}"
            )
        for b in self._cmd_btns.values():
            b.setEnabled(ok)

    # ── ARMAR com confirmação ─────────────────────────────────────────────────
    def _confirmar_armar(self, cmd):
        resp = QMessageBox.question(
            self, "⚠ Confirmar ARMAR",
            "Isso força o foguete para o estado SUBIDA.\n"
            "Certifique-se de que está seguro.\n\nContinuar?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if resp == QMessageBox.Yes:
            self.sig_comando.emit(int(cmd))


class LogPanel(QWidget):
    """Log de texto com mensagens raw e eventos."""

    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        self._txt = QTextEdit()
        self._txt.setReadOnly(True)
        self._txt.setFont(QFont("Consolas", 10))
        self._txt.setStyleSheet(
            f"background:#0A0E13; color:#39FF14; border:none;"
            f"selection-background-color:#1E2530;"
        )
        self._txt.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        lay.addWidget(self._txt)

    def append(self, msg: str, cor: str = None):
        safe = (msg.replace("&", "&amp;")
                   .replace("<", "&lt;")
                   .replace(">", "&gt;")
                   .replace(" ", "&nbsp;")
                   .replace("\n", "<br>"))
        color = cor if cor else "#39FF14"
        self._txt.append(f'<span style="color:{color};">{safe}</span>')
        sb = self._txt.verticalScrollBar()
        sb.setValue(sb.maximum())

    def limpar(self):
        self._txt.clear()
