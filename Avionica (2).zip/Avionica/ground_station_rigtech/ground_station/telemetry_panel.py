"""
telemetry_panel.py — Rigtech Ground Station
Painel lateral com valores numéricos e estado de voo.
"""

from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                              QFrame, QSizePolicy)
from PyQt5.QtCore    import Qt
from PyQt5.QtGui     import QFont
from protocol        import EstadoVoo, ESTADO_LABEL, ESTADO_COR

BG     = "#0D1117"
CARD   = "#13191F"
BORDER = "#1E2530"
WHITE  = "#E8EAF0"
MUTED  = "#6C7A89"
GREEN  = "#27AE60"
ORANGE = "#F5A623"
RED    = "#E74C3C"
BLUE   = "#2980B9"

_CARD_SS = (
    f"background:{CARD}; border:1px solid {BORDER}; border-radius:7px;"
)


class EstadoWidget(QFrame):
    """Badge de estado de voo — herda diretamente de QFrame para evitar
    problemas de stylesheet com widgets pai."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet(f"QFrame {{ {_CARD_SS} }}")
        self.setMinimumHeight(58)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(4, 5, 4, 5)
        lay.setSpacing(2)
        lay.setAlignment(Qt.AlignVCenter)

        tit = QLabel("ESTADO DE VOO")
        tit.setStyleSheet(
            f"color:{MUTED}; font-size:9px; font-weight:600;"
            f"background:transparent; border:none;"
        )
        tit.setAlignment(Qt.AlignCenter)
        lay.addWidget(tit)

        self._badge = QLabel("AGUARDANDO")
        self._badge.setAlignment(Qt.AlignCenter)
        self._badge.setWordWrap(False)
        self._badge.setFont(QFont("Consolas", 11, QFont.Bold))
        self._badge.setStyleSheet(
            f"color:{ORANGE}; background:transparent; border:none;"
        )
        lay.addWidget(self._badge)

    def set_estado(self, estado: EstadoVoo):
        self._badge.setText(ESTADO_LABEL.get(estado, "?"))
        self._badge.setStyleSheet(
            f"color:{ESTADO_COR.get(estado, WHITE)};"
            f"background:transparent; border:none;"
        )


class BigValueLabel(QFrame):
    """Card com valor numérico grande e unidade.
    Herda de QFrame para evitar problemas de stylesheet com o widget pai."""

    def __init__(self, titulo: str, unidade: str, cor: str = WHITE,
                 parent=None):
        super().__init__(parent)
        self._cor = cor
        self.setStyleSheet(f"QFrame {{ {_CARD_SS} }}")
        self.setMinimumHeight(48)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(8, 4, 8, 4)
        lay.setSpacing(1)

        tit = QLabel(titulo.upper())
        tit.setStyleSheet(
            f"color:{MUTED}; font-size:8px; font-weight:600;"
            f"background:transparent; border:none;"
        )
        tit.setAlignment(Qt.AlignCenter)
        lay.addWidget(tit)

        row = QHBoxLayout()
        row.setSpacing(3)

        self._val_lbl = QLabel("—")
        self._val_lbl.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self._val_lbl.setFont(QFont("Consolas", 18, QFont.Bold))
        self._val_lbl.setStyleSheet(
            f"color:{cor}; background:transparent; border:none;"
        )

        self._unit_lbl = QLabel(unidade)
        self._unit_lbl.setAlignment(Qt.AlignLeft | Qt.AlignBottom)
        self._unit_lbl.setStyleSheet(
            f"color:{MUTED}; font-size:9px; padding-bottom:2px;"
            f"background:transparent; border:none;"
        )

        row.addStretch()
        row.addWidget(self._val_lbl)
        row.addWidget(self._unit_lbl)
        row.addStretch()
        lay.addLayout(row)

    def set_value(self, v: float, fmt: str = "{:.1f}"):
        self._val_lbl.setText(fmt.format(v))

    def set_color(self, cor: str):
        self._val_lbl.setStyleSheet(
            f"color:{cor}; background:transparent; border:none;"
        )


class LinkIndicator(QWidget):
    """LED + texto de link RF."""

    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(6, 0, 6, 0)
        lay.setSpacing(6)

        self._dot = QLabel("●")
        self._dot.setStyleSheet(f"color:{RED}; font-size:13px;")
        self._lbl = QLabel("SEM SINAL")
        self._lbl.setStyleSheet(f"color:{MUTED}; font-size:10px;")
        lay.addWidget(self._dot)
        lay.addWidget(self._lbl)
        lay.addStretch()

    def set_online(self, ok: bool, msg: str = ""):
        if ok:
            self._dot.setStyleSheet(f"color:{GREEN}; font-size:13px;")
            self._lbl.setText(msg or "RF OK")
            self._lbl.setStyleSheet(f"color:{GREEN}; font-size:10px;")
        else:
            self._dot.setStyleSheet(f"color:{RED}; font-size:13px;")
            self._lbl.setText(msg or "SEM SINAL")
            self._lbl.setStyleSheet(f"color:{MUTED}; font-size:10px;")


class TelemetryPanel(QWidget):
    """Painel lateral completo de telemetria numérica."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedWidth(260)
        # Usa seletor de classe para não vazar em filhos QFrame
        self.setStyleSheet(f"TelemetryPanel {{ background:{BG}; }}")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(4)

        # Estado de voo
        self._estado_w = EstadoWidget()
        layout.addWidget(self._estado_w)

        # Valores numéricos
        self._alt_w  = BigValueLabel("Altitude",     "m",    GREEN)
        self._amax_w = BigValueLabel("Apogeu",        "m",    ORANGE)
        self._acc_w  = BigValueLabel("Aceleração",    "m/s²", WHITE)
        self._temp_w = BigValueLabel("Tempo de voo",  "s",    BLUE)

        for w in (self._alt_w, self._amax_w, self._acc_w, self._temp_w):
            layout.addWidget(w)

        # GPS
        gps = QFrame()
        gps.setStyleSheet(f"QFrame {{ {_CARD_SS} }}")
        gps.setMinimumHeight(44)
        gps_lay = QVBoxLayout(gps)
        gps_lay.setContentsMargins(8, 4, 8, 4)
        gps_lay.setSpacing(1)

        gps_tit = QLabel("GPS")
        gps_tit.setStyleSheet(
            f"color:{MUTED}; font-size:8px; font-weight:600;"
            f"background:transparent; border:none;"
        )
        gps_lay.addWidget(gps_tit)

        self._lat_lbl = QLabel("Lat: —")
        self._lon_lbl = QLabel("Lon: —")
        for lbl in (self._lat_lbl, self._lon_lbl):
            lbl.setStyleSheet(
                f"color:{WHITE}; font-family:Consolas; font-size:10px;"
                f"background:transparent; border:none;"
            )
            gps_lay.addWidget(lbl)
        layout.addWidget(gps)

        # Link RF
        self._link = LinkIndicator()
        layout.addWidget(self._link)

        layout.addStretch()

        # Estatísticas da sessão
        stats = QFrame()
        stats.setStyleSheet(f"QFrame {{ {_CARD_SS} }}")
        stats_lay = QHBoxLayout(stats)
        stats_lay.setContentsMargins(8, 4, 8, 4)
        stats_lay.setSpacing(12)

        self._pkts_lbl  = QLabel("Pkts: 0")
        self._erros_lbl = QLabel("Erros: 0")
        for lbl in (self._pkts_lbl, self._erros_lbl):
            lbl.setStyleSheet(
                f"color:{MUTED}; font-size:9px;"
                f"background:transparent; border:none;"
            )
            stats_lay.addWidget(lbl)
        stats_lay.addStretch()
        layout.addWidget(stats)

        self._pkts  = 0
        self._erros = 0
        self._t_inicio_voo = None
        self._alt_max = 0.0

    # ── API pública ───────────────────────────────────────────────────────────
    def set_estado(self, estado: EstadoVoo):
        self._estado_w.set_estado(estado)
        if estado == EstadoVoo.SUBIDA and self._t_inicio_voo is None:
            import time
            self._t_inicio_voo = time.time()

    def set_telemetria(self, altitude: float, aceleracao: float,
                       import_time=None):
        self._alt_w.set_value(altitude)
        self._acc_w.set_value(aceleracao)
        if altitude > self._alt_max:
            self._alt_max = altitude
            self._amax_w.set_value(altitude)
        if self._t_inicio_voo:
            import time
            self._temp_w.set_value(time.time() - self._t_inicio_voo, "{:.0f}")

    def set_gps(self, lat: float, lon: float):
        self._lat_lbl.setText(f"Lat: {lat:.6f}°")
        self._lon_lbl.setText(f"Lon: {lon:.6f}°")

    def set_link(self, ok: bool, msg: str = ""):
        self._link.set_online(ok, msg)

    def incr_pacotes(self):
        self._pkts += 1
        self._pkts_lbl.setText(f"Pkts: {self._pkts}")

    def incr_erros(self):
        self._erros += 1
        self._erros_lbl.setText(f"Erros: {self._erros}")

    def reset_sessao(self):
        self._pkts  = 0
        self._erros = 0
        self._alt_max = 0.0
        self._t_inicio_voo = None
        self._pkts_lbl.setText("Pkts: 0")
        self._erros_lbl.setText("Erros: 0")
        self._alt_w.set_value(0)
        self._amax_w.set_value(0)
        self._acc_w.set_value(0)
        self._temp_w.set_value(0)
        self._lat_lbl.setText("Lat: —")
        self._lon_lbl.setText("Lon: —")
