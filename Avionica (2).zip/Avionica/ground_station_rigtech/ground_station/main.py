"""
main.py — Rigtech Ground Station
Ponto de entrada: inicializa QApplication e MainWindow.

Uso:
    python main.py

Requisitos:
    pip install PyQt5 pyserial matplotlib numpy PyOpenGL
"""

import sys
import os

# Garante que PyQt5 usa a paleta escura no Windows
os.environ["QT_AUTO_SCREEN_SCALE_FACTOR"] = "1"

from PyQt5.QtWidgets import QApplication
from PyQt5.QtGui     import QFont, QPalette, QColor
from PyQt5.QtCore    import Qt

from main_window import MainWindow


def _dark_palette() -> QPalette:
    p = QPalette()
    c = {
        QPalette.Window:          "#0D1117",
        QPalette.WindowText:      "#E8EAF0",
        QPalette.Base:            "#13191F",
        QPalette.AlternateBase:   "#1A2030",
        QPalette.ToolTipBase:     "#0D1117",
        QPalette.ToolTipText:     "#E8EAF0",
        QPalette.Text:            "#E8EAF0",
        QPalette.Button:          "#13191F",
        QPalette.ButtonText:      "#E8EAF0",
        QPalette.BrightText:      "#FFFFFF",
        QPalette.Highlight:       "#F5A623",
        QPalette.HighlightedText: "#000000",
        QPalette.Link:            "#2980B9",
    }
    for role, hex_col in c.items():
        p.setColor(role, QColor(hex_col))
    return p


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("Rigtech Ground Station")
    app.setOrganizationName("Rigtech")
    app.setStyle("Fusion")
    app.setPalette(_dark_palette())
    app.setFont(QFont("Segoe UI", 9))

    win = MainWindow()
    win.show()

    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
