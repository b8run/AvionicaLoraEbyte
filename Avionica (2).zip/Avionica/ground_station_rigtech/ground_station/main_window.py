"""
main_window.py — Rigtech Ground Station
Janela principal: integra 3D, mapa, gráficos, telemetria e controle.
"""

import time
import csv
from datetime import datetime

from PyQt5.QtWidgets import (QMainWindow, QWidget, QHBoxLayout, QVBoxLayout,
                              QSplitter, QTabWidget, QLabel, QFileDialog,
                              QMessageBox, QStatusBar)
from PyQt5.QtCore    import Qt, QTimer, pyqtSlot
from PyQt5.QtGui     import QFont, QIcon

from protocol         import TelemetryPacket, Resp, EstadoVoo, build_command, Cmd
from serial_worker    import SerialWorker, SimWorker
from telemetry_panel  import TelemetryPanel
from command_panel    import CommandPanel, LogPanel
from charts           import DualChartPanel
from map_widget       import MapWidget, haversine_m
from rocket_3d        import Rocket3DWidget

BG      = "#0D1117"
CARD    = "#13191F"
BORDER  = "#1E2530"
WHITE   = "#E8EAF0"
MUTED   = "#6C7A89"
GREEN   = "#27AE60"
ORANGE  = "#F5A623"
RED     = "#E74C3C"
BLUE    = "#2980B9"

TIMEOUT_S = 5.0   # segundos sem pacote → alerta de link perdido


class MainWindow(QMainWindow):

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Rigtech — Ground Station | Foguete V1")
        self.resize(1400, 860)
        self.setMinimumSize(1100, 680)
        self.setStyleSheet(f"background:{BG}; color:{WHITE};")

        self._worker: SerialWorker = None
        self._session: list        = []         # log CSV em memória
        self._ultimo_pkt: float    = 0.0
        self._estado_atual         = EstadoVoo.AGUARDANDO
        self._lat_launch           = None
        self._lon_launch           = None
        self._apogeu_marcado       = False
        self._inicio_voo_marcado   = False
        self._dr_velocity: float   = 0.0        # m/s — dead reckoning
        self._dr_distance: float   = 0.0        # m   — dead reckoning
        self._dr_last_ts: float    = None       # timestamp do último pacote integrado

        self._build_ui()
        self._start_watchdog()
        self._start_auto_read()

    # ── Construção da UI ──────────────────────────────────────────────────────
    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ── Barra de comando (topo) ───────────────────────────────────────────
        self._cmd_panel = CommandPanel()
        self._cmd_panel.sig_conectar.connect(self._conectar)
        self._cmd_panel.sig_desconectar.connect(self._desconectar)
        self._cmd_panel.sig_simular.connect(self._iniciar_simulacao)
        self._cmd_panel.sig_comando.connect(self._enviar_comando)
        self._cmd_panel.sig_limpar_log.connect(self._limpar_sessao)
        self._cmd_panel.sig_exportar_csv.connect(self._exportar_csv)
        root.addWidget(self._cmd_panel)

        # ── Corpo principal ───────────────────────────────────────────────────
        body = QHBoxLayout()
        body.setContentsMargins(6, 6, 6, 4)
        body.setSpacing(6)
        root.addLayout(body, stretch=1)

        # ── Coluna esquerda: 3D + Telemetria ─────────────────────────────────
        left = QVBoxLayout()
        left.setSpacing(6)

        # 3D foguete
        self._rocket3d = Rocket3DWidget()
        left.addWidget(self._rocket3d, stretch=3)

        # painel de telemetria numérica
        self._telem = TelemetryPanel()
        left.addWidget(self._telem, stretch=2)

        body.addLayout(left)

        # ── Centro: abas (Gráficos | Mapa | Log) ─────────────────────────────
        self._tabs = QTabWidget()
        self._tabs.setStyleSheet(
            f"QTabWidget::pane {{ border:1px solid {BORDER}; background:{CARD}; }}"
            f"QTabBar::tab {{ background:{CARD}; color:{MUTED}; padding:6px 14px;"
            f"border:1px solid {BORDER}; border-bottom:none; border-radius:4px 4px 0 0;}}"
            f"QTabBar::tab:selected {{ background:{BG}; color:{WHITE}; }}"
        )

        # Tab Gráficos
        self._charts = DualChartPanel()
        self._tabs.addTab(self._charts, "📈  Gráficos")

        # Tab Mapa
        self._map = MapWidget()
        self._map.base_definida.connect(self._on_base_manual)
        self._tabs.addTab(self._map, "🗺  Mapa")

        # Tab Log
        log_container = QWidget()
        log_lay = QVBoxLayout(log_container)
        log_lay.setContentsMargins(0, 0, 0, 0)
        log_lay.setSpacing(0)
        self._log = LogPanel()
        log_lay.addWidget(self._log)
        self._tabs.addTab(log_container, "📋  Log")

        body.addWidget(self._tabs, stretch=1)

        # ── Status bar ────────────────────────────────────────────────────────
        self._statusbar = QStatusBar()
        self._statusbar.setStyleSheet(
            f"background:{CARD}; color:{MUTED}; font-size:10px;"
        )
        self.setStatusBar(self._statusbar)
        self._statusbar.showMessage("Desconectado — selecione a porta serial e clique CONECTAR")

    # ── Auto-READ em AGUARDANDO ───────────────────────────────────────────────
    def _start_auto_read(self):
        self._auto_read_timer = QTimer(self)
        self._auto_read_timer.setInterval(8000)
        self._auto_read_timer.timeout.connect(self._auto_read_tick)

    def _auto_read_tick(self):
        if self._worker and self._estado_atual == EstadoVoo.AGUARDANDO:
            self._worker.enviar(build_command(Cmd.READ))

    # ── Watchdog de link ──────────────────────────────────────────────────────
    def _start_watchdog(self):
        self._watchdog = QTimer(self)
        self._watchdog.setInterval(1000)
        self._watchdog.timeout.connect(self._check_link)
        self._watchdog.start()

    def _check_link(self):
        if self._worker is None:
            return
        if time.time() - self._ultimo_pkt > TIMEOUT_S:
            self._telem.set_link(False, f"Sem pacote há >{TIMEOUT_S:.0f}s")

    # ── Serial ────────────────────────────────────────────────────────────────
    @pyqtSlot(str, int)
    def _conectar(self, porta: str, baud: int):
        if self._worker:
            self._worker.parar()
        self._worker = SerialWorker(porta, baud)
        self._worker.pacote_recebido.connect(self._on_pacote)
        self._worker.raw_log.connect(self._on_raw)
        self._worker.status_changed.connect(self._on_status)
        self._worker.erro.connect(self._on_erro)
        self._worker.start()

    @pyqtSlot()
    def _iniciar_simulacao(self):
        if self._worker:
            self._worker.parar()
        self._worker = SimWorker()
        self._worker.pacote_recebido.connect(self._on_pacote)
        self._worker.raw_log.connect(self._on_raw)
        self._worker.status_changed.connect(self._on_status)
        self._worker.erro.connect(self._on_erro)
        self._worker.start()

    @pyqtSlot()
    def _desconectar(self):
        self._auto_read_timer.stop()
        if self._worker:
            self._worker.parar()
            self._worker = None
        self._cmd_panel.set_conectado(False)
        self._telem.set_link(False, "Desconectado")
        self._statusbar.showMessage("Desconectado")

    @pyqtSlot(int)
    def _enviar_comando(self, cmd_val: int):
        if self._worker:
            self._worker.enviar(build_command(Cmd(cmd_val)))

    # ── Handlers de eventos ───────────────────────────────────────────────────
    @pyqtSlot(object)
    def _on_pacote(self, pkt: TelemetryPacket):
        self._ultimo_pkt = time.time()
        self._telem.incr_pacotes()

        if pkt.resp == Resp.DATA:
            self._handle_telemetria(pkt)

        elif pkt.resp == Resp.GPS:
            self._handle_gps(pkt)

        elif pkt.resp == Resp.PONG:
            self._telem.set_link(True, "PONG ✓")
            self._statusbar.showMessage("PONG recebido — foguete online")

    def _handle_telemetria(self, pkt: TelemetryPacket):
        estado    = pkt.estado
        altitude  = pkt.altitude
        aceleracao = pkt.aceleracao
        ts = time.time()

        # Detecta mudança de estado
        if estado != self._estado_atual:
            anterior = self._estado_atual
            self._estado_atual = estado
            # Marcar início de voo
            if anterior == EstadoVoo.AGUARDANDO and estado == EstadoVoo.SUBIDA:
                self._auto_read_timer.stop()
                if not self._inicio_voo_marcado:
                    self._charts.marcar_inicio_voo()
                    self._inicio_voo_marcado = True
                    self._log.append("*** DECOLAGEM DETECTADA ***", GREEN)
            # Marcar apogeu
            if anterior == EstadoVoo.SUBIDA and estado == EstadoVoo.DESCIDA:
                if not self._apogeu_marcado:
                    self._charts.marcar_apogeu()
                    self._apogeu_marcado = True
                    self._log.append("*** APOGEU DETECTADO ***", RED)

        # Dead reckoning: integra (a_medida - g) → velocidade → distância
        _G = 9.81
        if estado in (EstadoVoo.SUBIDA, EstadoVoo.DESCIDA):
            if self._dr_last_ts is not None:
                dt = ts - self._dr_last_ts
                self._dr_velocity += (aceleracao - _G) * dt
                self._dr_distance += self._dr_velocity * dt
            self._dr_last_ts = ts
            self._charts.adicionar_dr_dist(max(0.0, self._dr_distance), ts)
        elif estado == EstadoVoo.AGUARDANDO:
            self._dr_velocity = 0.0
            self._dr_distance = 0.0
            self._dr_last_ts  = None

        # Atualiza widgets
        self._telem.set_estado(estado)
        self._telem.set_telemetria(altitude, aceleracao)
        self._telem.set_link(True, f"RF OK — {int(ts % 1000)}ms")
        self._rocket3d.atualizar(int(estado), altitude, aceleracao)
        self._charts.adicionar_telemetria(altitude, aceleracao, ts)

        # Log CSV
        self._session.append({
            "ts": datetime.fromtimestamp(ts).isoformat(),
            "resp": "DATA",
            "estado": estado.name,
            "altitude": altitude,
            "aceleracao": aceleracao,
            "lat": "", "lon": "",
        })

        self._statusbar.showMessage(
            f"Alt: {altitude:.1f}m | Acel: {aceleracao:.1f}m/s² | "
            f"Estado: {estado.name} | pkts: {self._telem._pkts}"
        )

    @pyqtSlot(float, float)
    def _on_base_manual(self, lat: float, lon: float):
        self._lat_launch = lat
        self._lon_launch = lon
        self._log.append(
            f"   [Base definida: {lat:.6f}, {lon:.6f}]", ORANGE
        )

    def _handle_gps(self, pkt: TelemetryPacket):
        lat = pkt.latitude
        lon = pkt.longitude
        ts  = time.time()

        self._telem.set_gps(lat, lon)

        # Primeiro GPS → ponto de lançamento (se ainda não definido manualmente)
        if self._lat_launch is None:
            self._lat_launch = lat
            self._lon_launch = lon
            self._map.set_launch(lat, lon)
            self._log.append("   [Ponto de lancamento definido]", ORANGE)

        self._map.add_gps_point(lat, lon)

        # Distância da base → gráfico
        if self._lat_launch is not None and self._lon_launch is not None:
            dist = haversine_m(self._lat_launch, self._lon_launch, lat, lon)
            self._charts.adicionar_gps_dist(dist, ts)

        # Se pousado → ponto de queda
        if self._estado_atual == EstadoVoo.POUSADO:
            self._map.set_landing(lat, lon)
            self._log.append("   [Ponto de queda definido]", RED)

        self._session.append({
            "ts": datetime.fromtimestamp(ts).isoformat(),
            "resp": "GPS",
            "estado": self._estado_atual.name,
            "altitude": "", "aceleracao": "",
            "lat": lat, "lon": lon,
        })

    @pyqtSlot(str)
    def _on_raw(self, msg: str):
        self._log.append(msg)

    @pyqtSlot(bool, str)
    def _on_status(self, ok: bool, msg: str):
        self._cmd_panel.set_conectado(ok)
        self._telem.set_link(ok, msg)
        self._statusbar.showMessage(msg)
        cor = GREEN if ok else RED
        self._log.append(f"[{_ts()}] {msg}", cor)
        if ok and self._estado_atual == EstadoVoo.AGUARDANDO:
            self._auto_read_timer.start()
        elif not ok:
            self._auto_read_timer.stop()

    @pyqtSlot(str)
    def _on_erro(self, msg: str):
        self._telem.incr_erros()
        self._log.append(f"[{_ts()}] ERRO: {msg}", RED)
        QMessageBox.critical(self, "Erro de conexão serial", msg)

    # ── Ações de sessão ───────────────────────────────────────────────────────
    def _limpar_sessao(self):
        self._session.clear()
        self._apogeu_marcado      = False
        self._inicio_voo_marcado  = False
        self._dr_velocity         = 0.0
        self._dr_distance         = 0.0
        self._dr_last_ts          = None
        self._lat_launch          = None
        self._lon_launch          = None
        self._estado_atual        = EstadoVoo.AGUARDANDO
        self._log.limpar()
        self._charts.limpar()
        self._map.limpar()
        self._telem.reset_sessao()
        self._rocket3d.atualizar(0, 0.0, 0.0)
        self._log.append(f"[{_ts()}] Sessão limpa", MUTED)

    def _exportar_csv(self):
        if not self._session:
            QMessageBox.information(self, "Exportar", "Nenhum dado na sessão atual.")
            return
        fname, _ = QFileDialog.getSaveFileName(
            self, "Exportar CSV", f"sessao_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            "CSV (*.csv)"
        )
        if not fname:
            return
        campos = ["ts", "resp", "estado", "altitude", "aceleracao", "lat", "lon"]
        with open(fname, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=campos)
            w.writeheader()
            w.writerows(self._session)
        self._log.append(f"[{_ts()}] CSV exportado: {fname}", GREEN)
        QMessageBox.information(self, "Exportar", f"Salvo em:\n{fname}")

    def closeEvent(self, e):
        if self._worker:
            self._worker.parar()
        e.accept()


# ── Helpers ───────────────────────────────────────────────────────────────────
def _ts() -> str:
    return datetime.now().strftime("%H:%M:%S.%f")[:-3]
