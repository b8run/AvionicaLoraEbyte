/*
  Redundancia.ino — FOGUETE V1
  Placa de redundância — Arduino Nano
  Sensor: BMP180 (Adafruit BMP085 lib)
  Baseado na lógica de voo do Slave.ino v3.0

  Pinagem:
    LED R   → D7
    LED B   → D8
    LED G   → D2
    Squib 1 → D9  (usado neste projeto)
    Squib 2 → D10 (reservado)
    BAT_A0  → A0  (7,4V  — divisor 2× com 2×4,7kΩ)
    BAT_A1  → A1  (9,0V  — divisor 2× com 2×4,7kΩ)
    BAT_A2  → A2  (9,0V  — divisor 2× com 2×4,7kΩ)

  Parâmetros de voo:
    Armar   → altitude > 10 m (confirmado)
    Apogeu  → queda > 6 m abaixo do pico (confirmado)
    Squib   → 2s de duração

  Divisores de tensão (R1=R2=4,7kΩ):
    V_pino  = V_bat / 2
    V_bat   = (analogRead / 1023.0) * 5.0 * 2.0
    Nível   = V_bat / V_max  (0.0 – 1.0)

  Filtro de altitude (média móvel):
    O BMP180 tem ruído de leitura de ±3 m. Para reduzir esse ruído,
    a altitude usada pela máquina de estados é a média móvel das
    últimas 3 leituras brutas, atualizada a cada ciclo de amostragem.
*/

#include <Wire.h>
#include <Adafruit_BMP085.h>

// ─── Pinos ────────────────────────────────────────────────────────────────────
#define LED_R     7
#define LED_B     8
#define LED_G     2
#define SQUIB_1   9
#define SQUIB_2   10   // reservado

// ─── Divisores de tensão ──────────────────────────────────────────────────────
#define BAT_A0_PIN   A0
#define BAT_A1_PIN   A1
#define BAT_A2_PIN   A2

#define BAT_A0_VMAX  7.4f   // bateria 7,4V (2S LiPo)
#define BAT_A1_VMAX  9.0f   // bateria 9,0V
#define BAT_A2_VMAX  9.0f   // bateria 9,0V

// Limiar de alerta: 90% da tensão nominal (abaixo = bateria fraca)
// A0: 7,4 × 0,9 = 6,66V → nível 0,90
// A1/A2: 9,0 × 0,9 = 8,10V → nível 0,90
#define BAT_NIVEL_MINIMO  0.90f

// Intervalo de log das baterias e do sinal visual
#define BAT_LOG_MS        5000UL   // log serial a cada 5s
#define BAT_SINAL_MS     30000UL   // sinal LED a cada 30s (só no solo)

// ─── BMP180 ───────────────────────────────────────────────────────────────────
#define BMP_ADDR  0x77
Adafruit_BMP085 bmp;
bool statusBMP = false;

// ─── Parâmetros de voo ────────────────────────────────────────────────────────
#define ALT_ARMAR_M        1.0f   // altitude mínima para considerar em voo
#define APOGEU_QUEDA_M      2.0f   // queda do pico para confirmar apogeu
#define CONFIRM_ARMAR       5      // leituras consecutivas acima de ALT_ARMAR_M
#define CONFIRM_APOGEU      3      // leituras consecutivas de queda > APOGEU_QUEDA_M
#define SQUIB_DURACAO_MS 2000      // tempo com squib HIGH

// ─── Amostragem BMP ───────────────────────────────────────────────────────────
#define BMP_INTERVALO_MS   50      // ~20 Hz

// ─── Filtro de média móvel da altitude ────────────────────────────────────────
#define MEDIA_MOVEL_N      3       // tamanho da janela (3 últimas leituras)

// ─── Estados de voo ──────────────────────────────────────────────────────────
enum EstadoVoo { AGUARDANDO, ARMADO, APOGEU_CONFIRMADO, POUSADO };
EstadoVoo estado = AGUARDANDO;

// ─── Variáveis de altitude ────────────────────────────────────────────────────
float pressaoBase     = 0.0f;
float altitudeAtual   = 0.0f;   // valor FILTRADO (média móvel) — usado pela lógica de voo
float altitudeBruta    = 0.0f;  // última leitura direta do BMP, sem filtro (referência/debug)
float altitudeMaxima  = -9999.0f;

uint32_t tempoUltimaBMP        = 0;
uint32_t tempoAcionamentoSquib = 0;

// ─── Contadores anti-ruído ────────────────────────────────────────────────────
uint8_t contArmar   = 0;
uint8_t contApogeu  = 0;

// ─── Squib desligado flag ─────────────────────────────────────────────────────
bool squibDesligado = false;

// ─── Baterias ─────────────────────────────────────────────────────────────────
float batNivel[3]          = {0.0f, 0.0f, 0.0f};  // 0.0 – 1.0
uint32_t tempoUltimoBat    = 0;
uint32_t tempoUltimoSinalBat = 0;

// ─── Buffer da média móvel de altitude ────────────────────────────────────────
float bufferAlt[MEDIA_MOVEL_N];
uint8_t idxBufferAlt   = 0;
uint8_t amostrasAlt    = 0;   // quantas posições já foram preenchidas (até MEDIA_MOVEL_N)

// ─────────────────────────────────────────────────────────────────────────────
// LED helpers
// ─────────────────────────────────────────────────────────────────────────────
void ledSet(bool r, bool g, bool b) {
  digitalWrite(LED_R, r ? HIGH : LOW);
  digitalWrite(LED_G, g ? HIGH : LOW);
  digitalWrite(LED_B, b ? HIGH : LOW);
}
void ledOff()      { ledSet(false, false, false); }
void ledVermelho() { ledSet(true,  false, false); }
void ledAmarelo()  { ledSet(true,  true,  false); }
void ledVerde()    { ledSet(false, true,  false); }
void ledAzul()     { ledSet(false, false, true);  }
void ledBranco()   { ledSet(true,  true,  true);  }

// ─────────────────────────────────────────────────────────────────────────────
// Sinais visuais de boot / evento
// ─────────────────────────────────────────────────────────────────────────────
void piscaLed(void (*corFn)(), uint8_t n, uint16_t onMs, uint16_t offMs) {
  for (uint8_t i = 0; i < n; i++) {
    corFn();
    delay(onMs);
    ledOff();
    delay(offMs);
  }
}

void sinalBoot() {
  piscaLed(ledBranco, 3, 100, 100);
}

void sinalSensorOK(uint8_t n) {
  piscaLed(ledVerde, n, 120, 120);
}

void sinalSensorFalha() {
  piscaLed(ledVermelho, 3, 100, 80);
}

void sinalPronto() {
  // Amarelo fixo por 600ms como confirmação de "armado aguardando"
  ledAmarelo();
  delay(600);
}

void sinalEmVoo() {
  // Verde fixo — chamado uma vez na transição
  ledVerde();
}

void sinalApogeu() {
  // Pisca vermelho+amarelo rapidamente 6× → squib já foi acionado antes desta chamada
  for (int i = 0; i < 6; i++) {
    ledVermelho(); delay(60);
    ledAmarelo();  delay(60);
  }
  ledOff();
}

void sinalSquibDesligado() {
  piscaLed(ledAmarelo, 2, 150, 100);
  ledOff();
}

void sinalErroCritico() {
  // Loop infinito — trava o sistema
  while (true) {
    ledVermelho(); delay(400);
    ledOff();      delay(200);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Baseline de pressão
// ─────────────────────────────────────────────────────────────────────────────
float calcularBaseline(uint8_t amostras) {
  Serial.print(F("[BMP] Calculando baseline ("));
  Serial.print(amostras);
  Serial.println(F(" amostras)..."));

  double soma   = 0.0;
  uint8_t valid = 0;
  for (uint8_t i = 0; i < amostras; i++) {
    int32_t p = bmp.readPressure();
    if (p > 30000L && p < 110000L) {
      soma += p / 100.0;
      valid++;
    }
    delay(100);
  }
  if (valid == 0) {
    Serial.println(F("[BMP] ERRO: nenhuma amostra válida!"));
    return 0.0f;
  }
  float base = (float)(soma / valid);
  Serial.print(F("[BMP] Baseline: "));
  Serial.print(base, 4);
  Serial.print(F(" hPa ("));
  Serial.print(valid);
  Serial.println(F(" válidas)"));
  return base;
}

// ─────────────────────────────────────────────────────────────────────────────
// Leitura de altitude relativa (BRUTA — direto do BMP, sem filtro)
// ─────────────────────────────────────────────────────────────────────────────
float lerAltitudeBruta() {
  int32_t pressRaw = bmp.readPressure();
  if (pressRaw < 30000L || pressRaw > 110000L) return altitudeBruta; // mantém último válido
  float pressHPa = pressRaw / 100.0f;
  return 44330.0f * (1.0f - pow(pressHPa / pressaoBase, 0.1903f));
}

// ─────────────────────────────────────────────────────────────────────────────
// Filtro de média móvel — janela de MEDIA_MOVEL_N amostras
// ─────────────────────────────────────────────────────────────────────────────
// Insere uma nova leitura bruta no buffer circular e retorna a média
// das últimas amostrasAlt leituras (até MEDIA_MOVEL_N).
float atualizarMediaMovel(float novaLeitura) {
  bufferAlt[idxBufferAlt] = novaLeitura;
  idxBufferAlt = (idxBufferAlt + 1) % MEDIA_MOVEL_N;

  if (amostrasAlt < MEDIA_MOVEL_N) amostrasAlt++;

  float soma = 0.0f;
  for (uint8_t i = 0; i < amostrasAlt; i++) {
    soma += bufferAlt[i];
  }
  return soma / amostrasAlt;
}

// Inicializa o buffer com a primeira leitura repetida —
// evita transiente de média artificialmente baixa/alta no boot.
void inicializarMediaMovel(float valorInicial) {
  for (uint8_t i = 0; i < MEDIA_MOVEL_N; i++) {
    bufferAlt[i] = valorInicial;
  }
  idxBufferAlt = 0;
  amostrasAlt  = MEDIA_MOVEL_N;
}

// ─────────────────────────────────────────────────────────────────────────────
// Leitura e log das baterias
// ─────────────────────────────────────────────────────────────────────────────

// Lê os três canais e atualiza batNivel[] (0.0 – 1.0)
// Divisor com R1=R2=4,7kΩ → V_bat = V_pino × 2
// V_pino = (raw / 1023.0) × 5.0
void lerBaterias() {
  float raw0 = analogRead(BAT_A0_PIN);
  float raw1 = analogRead(BAT_A1_PIN);
  float raw2 = analogRead(BAT_A2_PIN);

  float v0 = (raw0 / 1023.0f) * 5.0f * 2.0f;
  float v1 = (raw1 / 1023.0f) * 5.0f * 2.0f;
  float v2 = (raw2 / 1023.0f) * 5.0f * 2.0f;

  batNivel[0] = constrain(v0 / BAT_A0_VMAX, 0.0f, 1.0f);
  batNivel[1] = constrain(v1 / BAT_A1_VMAX, 0.0f, 1.0f);
  batNivel[2] = constrain(v2 / BAT_A2_VMAX, 0.0f, 1.0f);
}

void logBaterias() {
  lerBaterias();
  Serial.print(F("[BAT] A0(7.4V): "));
  Serial.print(batNivel[0] * 100.0f, 1);
  Serial.print(F("% | A1(9V): "));
  Serial.print(batNivel[1] * 100.0f, 1);
  Serial.print(F("% | A2(9V): "));
  Serial.print(batNivel[2] * 100.0f, 1);
  Serial.println(F("%"));
}

// Pisca o LED indicando o status das baterias:
//   Todas OK  → 2× verde rápido
//   Alguma fraca → 1 piscada vermelha por bateria abaixo do limiar,
//                  com pausa entre canais para distinguir qual é qual
//                  (A0=1 piscada, A1=2 piscadas, A2=3 piscadas)
// Só deve ser chamado no estado AGUARDANDO (solo) — não interfere no voo.
void sinalBateriaFraca() {
  // Identifica quais baterias estão abaixo do limiar (90% da nominal)
  bool a0fraca = batNivel[0] < BAT_NIVEL_MINIMO;
  bool a1fraca = batNivel[1] < BAT_NIVEL_MINIMO;
  bool a2fraca = batNivel[2] < BAT_NIVEL_MINIMO;

  if (!a0fraca && !a1fraca && !a2fraca) {
    // Todas OK — 2 piscadas verdes rápidas
    piscaLed(ledVerde, 2, 80, 80);
    Serial.println(F("[BAT] Todas OK."));
    return;
  }

  // Pelo menos uma fraca — aviso serial
  Serial.print(F("[BAT] ALERTA bateria fraca:"));
  if (a0fraca) { Serial.print(F(" A0")); }
  if (a1fraca) { Serial.print(F(" A1")); }
  if (a2fraca) { Serial.print(F(" A2")); }
  Serial.println();

  // Sequência de piscadas vermelhas por canal fraco:
  // A0 → 1×, A1 → 2×, A2 → 3× (com pausa de 400ms entre grupos)
  if (a0fraca) {
    piscaLed(ledVermelho, 1, 200, 150);
    delay(400);
  }
  if (a1fraca) {
    piscaLed(ledVermelho, 2, 200, 150);
    delay(400);
  }
  if (a2fraca) {
    piscaLed(ledVermelho, 3, 200, 150);
    delay(400);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Verificação do sistema
// ─────────────────────────────────────────────────────────────────────────────
void verificacaoSistema() {
  Serial.println(F("========================================"));
  Serial.println(F("  VERIFICACAO — PLACA REDUNDANCIA"));
  Serial.println(F("========================================"));

  // BMP180
  Wire.beginTransmission(BMP_ADDR);
  byte err = Wire.endTransmission();
  if (err == 0) {
    statusBMP = bmp.begin();
    if (statusBMP) {
      float p = bmp.readPressure() / 100.0f;
      float t = bmp.readTemperature();
      if (p > 300.0f && p < 1100.0f) {
        Serial.print(F("  [OK] BMP180 | "));
        Serial.print(p, 2); Serial.print(F(" hPa | "));
        Serial.print(t, 1); Serial.println(F(" C"));
        sinalSensorOK(2);
      } else {
        statusBMP = false;
        Serial.println(F("  [FALHA] BMP180 | Leitura inválida"));
        sinalSensorFalha();
      }
    } else {
      Serial.println(F("  [FALHA] BMP180 | begin() = false"));
      sinalSensorFalha();
    }
  } else {
    Serial.print(F("  [FALHA] BMP180 | I2C erro ")); Serial.println(err);
    sinalSensorFalha();
  }

  // Squibs — LOW seguro
  pinMode(SQUIB_1, OUTPUT); digitalWrite(SQUIB_1, LOW);
  pinMode(SQUIB_2, OUTPUT); digitalWrite(SQUIB_2, LOW);
  Serial.println(F("  [OK] Squib 1 | LOW (seguro)"));
  Serial.println(F("  [OK] Squib 2 | LOW (seguro)"));

  // Baterias
  lerBaterias();
  Serial.print(F("  [BAT] A0(7.4V): ")); Serial.print(batNivel[0] * 100.0f, 1); Serial.println(F("%"));
  Serial.print(F("  [BAT] A1( 9V ): ")); Serial.print(batNivel[1] * 100.0f, 1); Serial.println(F("%"));
  Serial.print(F("  [BAT] A2( 9V ): ")); Serial.print(batNivel[2] * 100.0f, 1); Serial.println(F("%"));

  Serial.println(F("----------------------------------------"));
  Serial.print(F("  BMP180: ")); Serial.println(statusBMP ? F("OK") : F("FALHA"));
  Serial.println(F("  Squibs: OK (LOW)"));
  Serial.println(F("----------------------------------------"));

  if (!statusBMP) {
    Serial.println(F("  ERRO CRITICO: BMP ausente — travado."));
    sinalErroCritico();
  }
  Serial.println(F("  Sistema OK."));
  Serial.println(F("========================================\n"));
}

// ─────────────────────────────────────────────────────────────────────────────
// SETUP
// ─────────────────────────────────────────────────────────────────────────────
void setup() {
  Serial.begin(115200);
  delay(300);

  // Pinos de saída
  pinMode(LED_R,   OUTPUT); digitalWrite(LED_R,   LOW);
  pinMode(LED_G,   OUTPUT); digitalWrite(LED_G,   LOW);
  pinMode(LED_B,   OUTPUT); digitalWrite(LED_B,   LOW);
  pinMode(SQUIB_1, OUTPUT); digitalWrite(SQUIB_1, LOW);
  pinMode(SQUIB_2, OUTPUT); digitalWrite(SQUIB_2, LOW);

  ledVermelho();
  sinalBoot();

  Wire.begin();
  Wire.setClock(100000);

  verificacaoSistema();

  // Estabilização — vermelho pulsando ~3s
  Serial.println(F("Aguardando estabilizacao (3s)..."));
  for (int i = 0; i < 6; i++) {
    ledVermelho(); delay(250);
    ledOff();      delay(250);
  }

  pressaoBase = calcularBaseline(30);
  if (pressaoBase == 0.0f) {
    Serial.println(F("ERRO CRITICO: Baseline inválida!"));
    sinalErroCritico();
  }

  altitudeMaxima = -9999.0f;
  tempoUltimaBMP = millis();

  // Inicializa o filtro de média móvel com a altitude no momento da baseline
  // (deve ser ~0 m, já que pressaoBase foi calculada agora)
  altitudeBruta = lerAltitudeBruta();
  inicializarMediaMovel(altitudeBruta);
  altitudeAtual = altitudeBruta;

  // Pronto → amarelo
  sinalPronto();
  ledAmarelo();

  // Sinal inicial de bateria logo após o boot
  lerBaterias();
  sinalBateriaFraca();
  ledAmarelo();
  tempoUltimoSinalBat = millis();

  Serial.println(F("===== REDUNDANCIA PRONTA — AGUARDANDO ====="));
}

// ─────────────────────────────────────────────────────────────────────────────
// LOOP
// ─────────────────────────────────────────────────────────────────────────────
void loop() {
  uint32_t now = millis();

  // ── Leitura periódica do BMP + filtro de média móvel ────────────────────
  if (now - tempoUltimaBMP >= BMP_INTERVALO_MS) {
    altitudeBruta  = lerAltitudeBruta();
    altitudeAtual  = atualizarMediaMovel(altitudeBruta);   // valor usado pela lógica de voo
    tempoUltimaBMP = now;

    // Log serial em voo — mostra bruta e filtrada para comparação
    if (estado == ARMADO) {
      Serial.print(F("[ALT] bruta: ")); Serial.print(altitudeBruta, 2);
      Serial.print(F(" m | filtrada: ")); Serial.print(altitudeAtual, 2);
      Serial.print(F(" m | Max: ")); Serial.print(altitudeMaxima, 2); Serial.println(F(" m"));
    }
  }

  // ── Log periódico das baterias ───────────────────────────────────────────
  if (now - tempoUltimoBat >= BAT_LOG_MS) {
    logBaterias();
    tempoUltimoBat = now;
  }

  // ── Sinal visual de bateria (só no solo, a cada 30s) ─────────────────────
  if (estado == AGUARDANDO && (now - tempoUltimoSinalBat >= BAT_SINAL_MS)) {
    tempoUltimoSinalBat = now;
    sinalBateriaFraca();
    // Restaura LED do estado atual após o sinal
    ledAmarelo();
  }

  // ── Máquina de estados ───────────────────────────────────────────────────
  // A partir daqui, toda a lógica usa altitudeAtual (já filtrada pela média móvel)
  switch (estado) {

    // ── AGUARDANDO: espera subir acima do limiar de armar ──────────────────
    case AGUARDANDO: {
      if (altitudeAtual > ALT_ARMAR_M) {
        contArmar++;
        if (contArmar >= CONFIRM_ARMAR) {
          estado    = ARMADO;
          contArmar = 0;
          altitudeMaxima = altitudeAtual;
          sinalEmVoo();   // verde fixo
          Serial.print(F("[VOO] ARMADO — altitude: "));
          Serial.print(altitudeAtual, 2); Serial.println(F(" m"));
        }
      } else {
        contArmar = 0;
      }
      break;
    }

    // ── ARMADO: rastreia pico e detecta apogeu ─────────────────────────────
    case ARMADO: {
      if (altitudeAtual > altitudeMaxima) altitudeMaxima = altitudeAtual;

      if ((altitudeMaxima - altitudeAtual) > APOGEU_QUEDA_M) {
        contApogeu++;
        if (contApogeu >= CONFIRM_APOGEU) {
          // ─ SQUIB PRIMEIRO — sem bloqueio ─
          digitalWrite(SQUIB_1, HIGH);
          tempoAcionamentoSquib = millis();
          squibDesligado        = false;
          estado                = APOGEU_CONFIRMADO;
          contApogeu            = 0;

          sinalApogeu();   // pisca vermelho+amarelo — ocorre APÓS o squib HIGH

          Serial.print(F("[VOO] APOGEU CONFIRMADO! Alt max: "));
          Serial.print(altitudeMaxima, 2);
          Serial.println(F(" m — Squib 1 HIGH"));
        }
      } else {
        contApogeu = 0;
      }
      break;
    }

    // ── APOGEU_CONFIRMADO: aguarda 2s para desligar squib ─────────────────
    case APOGEU_CONFIRMADO: {
      // LED verde durante descida
      ledVerde();

      if (!squibDesligado && (millis() - tempoAcionamentoSquib >= SQUIB_DURACAO_MS)) {
        digitalWrite(SQUIB_1, LOW);
        squibDesligado = true;
        sinalSquibDesligado();   // amarelo 2× + apaga
        ledVerde();              // volta verde (descida)
        Serial.println(F("[VOO] Squib 1 desligado."));
      }

      // Detecção simplificada de pouso: altitude baixa e estável
      // (sem IMU, usa só altitude < 5m por alguns ciclos)
      static uint8_t contPouso = 0;
      if (altitudeAtual < 5.0f && altitudeAtual > -5.0f) {
        contPouso++;
        if (contPouso >= 20) {   // ~1s de leituras estáveis perto do solo
          estado    = POUSADO;
          contPouso = 0;
          Serial.println(F("[VOO] POUSO DETECTADO."));
          // Verde 3× lento
          for (int i = 0; i < 3; i++) {
            ledVerde(); delay(200);
            ledOff();   delay(200);
          }
          ledVermelho();   // estado permanente pousado
        }
      } else {
        contPouso = 0;
      }
      break;
    }

    // ── POUSADO: vermelho fixo + beacon periódico ─────────────────────────
    case POUSADO: {
      static uint32_t tempoUltimoBeacon = 0;
      if (millis() - tempoUltimoBeacon >= 90000UL) {
        tempoUltimoBeacon = millis();
        // Beacon: amarelo piscando 5s
        uint32_t inicio = millis();
        while (millis() - inicio < 5000UL) {
          ledAmarelo(); delay(250);
          ledOff();     delay(250);
        }
        ledVermelho();
        Serial.println(F("[BEACON] Sinal emitido."));
      }
      break;
    }
  }

  // ── Segurança: squib HIGH por mais de 3s → forçar LOW ────────────────────
  if (tempoAcionamentoSquib > 0 && !squibDesligado &&
      (millis() - tempoAcionamentoSquib >= 3000UL)) {
    digitalWrite(SQUIB_1, LOW);
    squibDesligado = true;
    Serial.println(F("[SEGURANCA] Squib desligado por timeout."));
  }
}