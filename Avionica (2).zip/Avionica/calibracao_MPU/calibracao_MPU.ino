#include <Wire.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>

Adafruit_MPU6050 mpu;

const unsigned long INTERVALO_MS = 500;
unsigned long ultimaLeitura = 0;
uint32_t conta = 0;

// Offsets do giroscopio (calculados na calibracao)
float offsetGx = 0, offsetGy = 0, offsetGz = 0;

// Offsets do acelerometro
float offsetAx = 0, offsetAy = 0, offsetAz = 0;

// -------------------------------------------------------
void calibrar() {
  const int N = 500;   // numero de amostras
  double somaGx = 0, somaGy = 0, somaGz = 0;
  double somaAx = 0, somaAy = 0, somaAz = 0;

  Serial.println();
  Serial.println(">>> CALIBRACAO INICIADA");
  Serial.println("    Mantenha o sensor COMPLETAMENTE PARADO e NIVELADO!");
  Serial.println("    Coletando 500 amostras...");

  // Descarta as primeiras 100 amostras (sensor estabilizando)
  for (int i = 0; i < 100; i++) {
    sensors_event_t a, g, t;
    mpu.getEvent(&a, &g, &t);
    delay(5);
  }

  // Coleta amostras
  for (int i = 0; i < N; i++) {
    sensors_event_t a, g, t;
    mpu.getEvent(&a, &g, &t);

    somaGx += g.gyro.x * RAD_TO_DEG;
    somaGy += g.gyro.y * RAD_TO_DEG;
    somaGz += g.gyro.z * RAD_TO_DEG;

    somaAx += a.acceleration.x;
    somaAy += a.acceleration.y;
    somaAz += a.acceleration.z;

    // Barra de progresso a cada 50 amostras
    if ((i + 1) % 50 == 0) {
      Serial.printf("    %d/%d amostras coletadas...\n", i + 1, N);
    }

    delay(5);
  }

  // Calcula medias
  offsetGx = somaGx / N;
  offsetGy = somaGy / N;
  offsetGz = somaGz / N;

  // Acelerometro: offset em X e Y deve ser 0 (sensor nivelado)
  // offset em Z deve ser 0 tambem (a biblioteca ja desconta a gravidade)
  offsetAx = somaAx / N;
  offsetAy = somaAy / N;
  offsetAz = somaAz / N;

  Serial.println();
  Serial.println(">>> CALIBRACAO CONCLUIDA!");
  Serial.println("    Offsets calculados:");
  Serial.printf("    Gx: %+.4f °/s\n", offsetGx);
  Serial.printf("    Gy: %+.4f °/s\n", offsetGy);
  Serial.printf("    Gz: %+.4f °/s\n", offsetGz);
  Serial.printf("    Ax: %+.4f m/s²\n", offsetAx);
  Serial.printf("    Ay: %+.4f m/s²\n", offsetAy);
  Serial.printf("    Az: %+.4f m/s²\n", offsetAz);
  Serial.println();
  Serial.println("    Salve esses valores se quiser usar sem recalibrar!");
  Serial.println();
}

// -------------------------------------------------------
void setup() {
  Serial.begin(115200);
  delay(1000);

  Wire.begin(21, 22);
  delay(100);

  Serial.println("========================================");
  Serial.println("  MPU6050 COM CALIBRACAO - ESP32 WROOM");
  Serial.println("========================================");

  if (!mpu.begin()) {
    Serial.println("FALHA: MPU6050 nao encontrado!");
    while (1) delay(1000);
  }

  // Adicione isso no setup() antes de chamar calibrar()
  Serial.println("Aquecendo sensor, aguarde 15 segundos...");
  unsigned long inicio = millis();
  while (millis() - inicio < 15000) {
    sensors_event_t a, g, t;
    mpu.getEvent(&a, &g, &t);
    Serial.printf("\r  Temp: %.2f °C  ", t.temperature);
    delay(200);
  }
  Serial.println();

  mpu.setAccelerometerRange(MPU6050_RANGE_8_G);
  mpu.setGyroRange(MPU6050_RANGE_500_DEG);
  mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);

  Serial.println("OK: MPU6050 inicializado!");
  Serial.println("  Acelerometro: +/- 8g");
  Serial.println("  Giroscopio:   +/- 500 deg/s");
  Serial.println("  Filtro:       21 Hz");

  calibrar();

  Serial.printf("  %-5s %-9s %-9s %-9s %-9s %-9s %-9s %-8s\n",
                "#", "Ax(m/s²)", "Ay(m/s²)", "Az(m/s²)",
                "Gx(°/s)", "Gy(°/s)", "Gz(°/s)", "Temp(C)");
  Serial.println("----------------------------------------------------------------------");
}

// -------------------------------------------------------
void loop() {
  if (millis() - ultimaLeitura >= INTERVALO_MS) {
    ultimaLeitura = millis();
    conta++;

    sensors_event_t a, g, temp;
    mpu.getEvent(&a, &g, &temp);

    // Aplica offsets
    float Ax = a.acceleration.x - offsetAx;
    float Ay = a.acceleration.y - offsetAy;
    float Az = a.acceleration.z - offsetAz;
    float Gx = (g.gyro.x * RAD_TO_DEG) - offsetGx;
    float Gy = (g.gyro.y * RAD_TO_DEG) - offsetGy;
    float Gz = (g.gyro.z * RAD_TO_DEG) - offsetGz;

    Serial.printf("  %-5lu %-9.3f %-9.3f %-9.3f %-9.3f %-9.3f %-9.3f %-8.2f\n",
                  conta, Ax, Ay, Az, Gx, Gy, Gz, temp.temperature);
  }
}